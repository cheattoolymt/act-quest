package com.iaigiri.koumakan.rb

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

