import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/card_model.dart';
import '../models/game_models.dart';
import '../providers/game_provider.dart';
import '../services/battle_service.dart';
import '../widgets/card_widget.dart';
import '../widgets/hud_widget.dart';
import 'battle_result_screen.dart';

class BattleScreen extends StatefulWidget {
  final StageData? stage;
  final int difficulty;
  final String playerName;
  final List<String> playerDeckIds;
  // PvP用
  final bool isPvp;
  final bool isHost;

  const BattleScreen({
    super.key,
    this.stage,
    required this.difficulty,
    required this.playerName,
    required this.playerDeckIds,
    this.isPvp = false,
    this.isHost = false,
  });

  @override
  State<BattleScreen> createState() => _BattleScreenState();
}

class _BattleScreenState extends State<BattleScreen>
    with TickerProviderStateMixin {
  BattleState? _battleState;
  bool _usedLegendary = false;
  bool _initialized = false;

  // ===== エフェクト =====
  late AnimationController _dmgFlashCtrl;
  late Animation<double> _dmgFlashAnim;
  late AnimationController _fullFlashCtrl;
  late Animation<double> _fullFlashAnim;
  Color _fullFlashColor = const Color(0xFFFF4400);
  String? _burstText;
  Color _burstColor = Colors.white;
  late AnimationController _burstCtrl;
  late Animation<double> _burstScaleAnim;
  late Animation<double> _burstFadeAnim;

  BattleState get _battle => _battleState!;

  @override
  void initState() {
    super.initState();
    _initEffects();
    // didChangeDependencies後に呼ぶためPostFrameCallbackを使用
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _initBattle();
    });
  }

  void _initEffects() {
    _dmgFlashCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _dmgFlashAnim = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: 1.0), weight: 25),
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 0.0), weight: 75),
    ]).animate(_dmgFlashCtrl);

    _fullFlashCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fullFlashAnim = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: 0.6), weight: 30),
      TweenSequenceItem(tween: Tween(begin: 0.6, end: 0.0), weight: 70),
    ]).animate(_fullFlashCtrl);

    _burstCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
    _burstScaleAnim = Tween<double>(begin: 0.5, end: 1.3).animate(
      CurvedAnimation(parent: _burstCtrl, curve: Curves.easeOutBack));
    _burstFadeAnim = Tween<double>(begin: 1.0, end: 0.0).animate(
      CurvedAnimation(parent: _burstCtrl, curve: const Interval(0.4, 1.0, curve: Curves.easeIn)));
    _burstCtrl.addStatusListener((s) {
      if (s == AnimationStatus.completed) setState(() => _burstText = null);
    });
  }

  void _triggerDamageFlash() {
    if (!mounted) return;
    _dmgFlashCtrl.forward(from: 0);
  }

  void _triggerFullFlash(Color color) {
    if (!mounted) return;
    setState(() => _fullFlashColor = color);
    _fullFlashCtrl.forward(from: 0);
  }

  void _triggerCardBurst(String name, Color color) {
    if (!mounted) return;
    setState(() {
      _burstText = name;
      _burstColor = color;
    });
    _burstCtrl.forward(from: 0);
  }

  void _initBattle() {
    final stage = widget.stage;
    final diff = Difficulty.values[widget.difficulty];

    // プレイヤーデッキ構築
    final pDeck = List<String>.from(widget.playerDeckIds);

    // エネミーデッキ
    List<String> eDeck;
    String enemyName;
    int enemyHp;
    int enemyMana;

    if (stage != null) {
      eDeck = List<String>.from(stage.enemyDeckIds);
      enemyName = stage.enemyName;
      enemyHp = stage.enemyHp;
      enemyMana = stage.enemyMaxMana;
    } else {
      // PvP - 後で設定
      eDeck = List<String>.from(CardDatabase.starterDeckIds);
      enemyName = 'OPPONENT';
      enemyHp = 30;
      enemyMana = 10;
    }

    // GameProviderからロールを取得
    final gp = context.read<GameProvider>();
    final playerRole = gp.playerRole;

    final player = PlayerState(
      id: 'player',
      name: widget.playerName,
      role: playerRole,
      hp: 30,
      maxHp: 30,
      deck: pDeck,
    );

    final enemy = PlayerState(
      id: 'enemy',
      name: enemyName,
      // ソロ: 自分がホワイト→敵はブラック、自分がブラック→敵はホワイト
      role: playerRole == PlayerRole.white ? PlayerRole.black : PlayerRole.white,
      hp: enemyHp,
      maxHp: enemyHp,
      deck: eDeck,
      maxMana: enemyMana,
    );

    _battleState = BattleState(
      player: player,
      enemy: enemy,
      difficulty: diff,
    );
    _battle.startBattle();
    _battle.addListener(_onBattleUpdate);
    if (mounted) setState(() => _initialized = true);
  }

  void _onBattleUpdate() {
    if (!mounted) return;
    setState(() {});
    // 結果に応じてフルフラッシュ
    if (_battle.result == BattleResult.playerWin) {
      _triggerFullFlash(const Color(0xFF00FF88));
    } else if (_battle.result == BattleResult.playerLose) {
      _triggerDamageFlash();
      _triggerFullFlash(const Color(0xFFFF2222));
    } else if (_battle.result == BattleResult.draw) {
      _triggerFullFlash(const Color(0xFF888888));
    }
    if (_battle.result != BattleResult.ongoing) {
      Future.delayed(const Duration(milliseconds: 800), () {
        if (mounted) _navigateToResult();
      });
    }
  }

  void _navigateToResult() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => BattleResultScreen(
          result: _battle.result,
          stage: widget.stage,
          difficulty: widget.difficulty,
          noPlayerDamage: _battle.noPlayerDamageTaken,
          usedLegendary: _usedLegendary,
          playerHp: _battle.player.hp,
          enemyHp: _battle.enemy.hp,
          turnNumber: _battle.turnNumber,
        ),
      ),
    );
  }

  @override
  void dispose() {
    try { _battleState?.removeListener(_onBattleUpdate); } catch (_) {}
    _dmgFlashCtrl.dispose();
    _fullFlashCtrl.dispose();
    _burstCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_initialized || _battleState == null) {
      return const Scaffold(
        backgroundColor: Color(0xFF050510),
        body: Center(child: CircularProgressIndicator(color: Color(0xFF00FF88))),
      );
    }
    return Scaffold(
      backgroundColor: const Color(0xFF050510),
      body: SafeArea(
        child: AnimatedBuilder(
          animation: Listenable.merge([_dmgFlashAnim, _fullFlashAnim]),
          builder: (context, child) {
            return Stack(
              children: [
                // ===== メインUI =====
                Column(
                  children: [
                    // 敵HUD
                    HudWidget(
                      name: _battle.enemy.name,
                      hp: _battle.enemy.hp,
                      maxHp: _battle.enemy.maxHp,
                      shield: _battle.enemy.shield,
                      mana: _battle.enemy.mana,
                      maxMana: _battle.currentMaxMana,
                      isEnemy: true,
                      poisonTurns: _battle.enemy.poisonTurns,
                    ),
                    // バトルログ
                    Expanded(flex: 3, child: _buildBattleLog()),
                    // ターン情報
                    _buildTurnInfo(),
                    // プレイヤーHUD
                    HudWidget(
                      name: _battle.player.name,
                      hp: _battle.player.hp,
                      maxHp: _battle.player.maxHp,
                      shield: _battle.player.shield,
                      mana: _battle.player.mana,
                      maxMana: _battle.currentMaxMana,
                      isEnemy: false,
                      poisonTurns: _battle.player.poisonTurns,
                    ),
                    // 手札エリア
                    Expanded(flex: 4, child: _buildHandArea()),
                    // アクションボタン
                    _buildActionBar(),
                  ],
                ),

                // ===== ダメージフラッシュ =====
                if (_dmgFlashAnim.value > 0)
                  IgnorePointer(
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: RadialGradient(
                          center: Alignment.center,
                          radius: 1.5,
                          colors: [
                            Colors.transparent,
                            Colors.red.withValues(alpha: _dmgFlashAnim.value * 0.55),
                          ],
                        ),
                      ),
                    ),
                  ),

                // ===== 全画面フラッシュ =====
                if (_fullFlashAnim.value > 0)
                  IgnorePointer(
                    child: Container(
                      color: _fullFlashColor.withValues(alpha: _fullFlashAnim.value),
                    ),
                  ),

                // ===== カードバースト =====
                if (_burstText != null)
                  IgnorePointer(
                    child: Center(
                      child: FadeTransition(
                        opacity: _burstFadeAnim,
                        child: ScaleTransition(
                          scale: _burstScaleAnim,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                            decoration: BoxDecoration(
                              color: Colors.black.withValues(alpha: 0.75),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: _burstColor, width: 2),
                              boxShadow: [
                                BoxShadow(
                                  color: _burstColor.withValues(alpha: 0.5),
                                  blurRadius: 20, spreadRadius: 4,
                                ),
                              ],
                            ),
                            child: Text(
                              _burstText!,
                              style: TextStyle(
                                color: _burstColor,
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1.5,
                                shadows: [
                                  Shadow(color: _burstColor.withValues(alpha: 0.8), blurRadius: 8),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildBattleLog() {
    final logs = List.of(_battle.logs);
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: const Color(0xFF080812),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFF1A1A3A)),
      ),
      child: ListView.builder(
        reverse: true,
        itemCount: logs.length,
        itemBuilder: (context, index) {
          final log = logs[index];
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 1),
            child: Text(
              log.message,
              style: TextStyle(
                color: log.isPlayerAction
                    ? const Color(0xFF88FFAA)
                    : const Color(0xFFFF8888),
                fontSize: 11,
                fontFamily: 'monospace',
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildTurnInfo() {
    final diff = ['EASY', 'NORMAL', 'HARD'][widget.difficulty];
    final diffColor = [
      const Color(0xFF44FF88),
      const Color(0xFFFFAA00),
      const Color(0xFFFF4444)
    ][widget.difficulty];

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'TURN ${_battle.turnNumber}',
            style: const TextStyle(
              color: Color(0xFF00AAFF),
              fontSize: 13,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: _battle.isPlayerTurn
                  ? const Color(0xFF00FF88).withValues(alpha: 0.15)
                  : const Color(0xFFFF4444).withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: _battle.isPlayerTurn
                    ? const Color(0xFF00FF88).withValues(alpha: 0.5)
                    : const Color(0xFFFF4444).withValues(alpha: 0.5),
              ),
            ),
            child: Text(
              _battle.isAiThinking
                  ? '⏳ 敵のターン...'
                  : _battle.isPlayerTurn
                      ? '✅ あなたのターン'
                      : '⏳ 敵のターン',
              style: TextStyle(
                color: _battle.isPlayerTurn
                    ? const Color(0xFF00FF88)
                    : const Color(0xFFFF4444),
                fontSize: 11,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
            decoration: BoxDecoration(
              color: diffColor.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              diff,
              style: TextStyle(color: diffColor, fontSize: 10, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHandArea() {
    final hand = _battle.player.hand;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: hand.isEmpty
          ? const Center(
              child: Text(
                '手札なし',
                style: TextStyle(color: Color(0xFF444466), fontSize: 13),
              ),
            )
          : ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: hand.length,
              itemBuilder: (context, index) {
                final cardId = hand[index];
                final card = CardDatabase.getById(cardId);
                if (card == null) return const SizedBox.shrink();
                final canPlay = _battle.isPlayerTurn &&
                    !_battle.isAiThinking &&
                    card.cost <= _battle.player.mana &&
                    _battle.result == BattleResult.ongoing;
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: CardWidget(
                    card: card,
                    canPlay: canPlay,
                    showDetailOnLongPress: false,
                    onTap: () {
                      showCardDetailWithAction(
                        context: context,
                        card: card,
                        canUse: canPlay,
                        onUse: () {
                          if (card.rarity == CardRarity.legendary) {
                            _usedLegendary = true;
                          }
                          _triggerCardBurst(card.name, card.typeColor);
                          final hpBefore = _battle.player.hp;
                          final shieldBefore = _battle.player.shield;
                          _battle.playCard(cardId);
                          if (_battle.player.hp < hpBefore) {
                            _triggerDamageFlash();
                          } else if (_battle.player.hp > hpBefore) {
                            _triggerFullFlash(const Color(0xFF00FF88)); // 回復 → 緑
                          } else if (_battle.player.shield > shieldBefore) {
                            _triggerFullFlash(const Color(0xFF00AAFF)); // シールド → 青
                          }
                        },
                      );
                    },
                  ),
                );
              },
            ),
    );
  }

  Widget _buildActionBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          // 逃げるボタン
          OutlinedButton(
            onPressed: () {
              showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  backgroundColor: const Color(0xFF0F1A2E),
                  title: const Text('降参', style: TextStyle(color: Color(0xFFFF4444))),
                  content: const Text('バトルを降参しますか？'),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('戻る'),
                    ),
                    TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.of(context).pushReplacement(
                          MaterialPageRoute(
                            builder: (_) => BattleResultScreen(
                              result: BattleResult.playerLose,
                              stage: widget.stage,
                              difficulty: widget.difficulty,
                              noPlayerDamage: false,
                              usedLegendary: _usedLegendary,
                              playerHp: 0,
                              enemyHp: _battle.enemy.hp,
                              turnNumber: _battle.turnNumber,
                            ),
                          ),
                        );
                      },
                      child: const Text('降参', style: TextStyle(color: Color(0xFFFF4444))),
                    ),
                  ],
                ),
              );
            },
            style: OutlinedButton.styleFrom(
              foregroundColor: const Color(0xFFFF4444),
              side: const BorderSide(color: Color(0xFF441111)),
            ),
            child: const Text('降参', style: TextStyle(fontSize: 12)),
          ),
          const Spacer(),
          // マナ表示
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: const Color(0xFF0A1A3A),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: const Color(0xFF1A3A7C)),
            ),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: List.generate(_battle.currentMaxMana, (i) {
                  return Container(
                    width: 10,
                    height: 10,
                    margin: const EdgeInsets.symmetric(horizontal: 1),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: i < _battle.player.mana
                          ? const Color(0xFF00AAFF)
                          : const Color(0xFF1A1A3A),
                    ),
                  );
                }),
              ),
            ),
          ),
          const Spacer(),
          // ターン終了ボタン
          ElevatedButton(
            onPressed: (_battle.isPlayerTurn &&
                    !_battle.isAiThinking &&
                    _battle.result == BattleResult.ongoing)
                ? () async {
                    _battle.endPlayerTurn();
                    await _battle.processAiTurn();
                  }
                : null,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF00FF88),
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            ),
            child: const Text(
              'ターン終了',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }
}
