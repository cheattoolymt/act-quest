import 'package:flutter/material.dart';
import '../models/card_model.dart';

class CardWidget extends StatelessWidget {
  final CardModel card;
  final bool canPlay;
  final bool compact;
  final VoidCallback? onTap;
  /// trueにすると長押し（またはcompactモードで通常タップ）で詳細ダイアログを表示
  final bool showDetailOnLongPress;

  const CardWidget({
    super.key,
    required this.card,
    required this.canPlay,
    this.compact = false,
    this.onTap,
    this.showDetailOnLongPress = true,
  });

  void _showDetail(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => _CardDetailDialog(card: card),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      onLongPress: showDetailOnLongPress ? () => _showDetail(context) : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: compact ? null : 120,
        decoration: BoxDecoration(
          color: const Color(0xFF0D1A2E),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: canPlay
                ? card.typeColor.withValues(alpha: 0.8)
                : card.typeColor.withValues(alpha: 0.3),
            width: canPlay ? 2 : 1,
          ),
          boxShadow: canPlay
              ? [
                  BoxShadow(
                    color: card.typeColor.withValues(alpha: 0.2),
                    blurRadius: 8,
                    spreadRadius: 1,
                  ),
                ]
              : [],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // カードヘッダー（コスト＋タイプ）
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: card.typeColor.withValues(alpha: 0.15),
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(8)),
              ),
              child: Row(
                children: [
                  Container(
                    width: 22,
                    height: 22,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color:
                          const Color(0xFF00AAFF).withValues(alpha: 0.3),
                      border: Border.all(
                        color: const Color(0xFF00AAFF).withValues(alpha: 0.6),
                      ),
                    ),
                    child: Center(
                      child: Text(
                        '${card.cost}',
                        style: const TextStyle(
                          color: Color(0xFF00AAFF),
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  const Spacer(),
                  Text(card.typeIcon,
                      style: const TextStyle(fontSize: 14)),
                ],
              ),
            ),
            // カード名
            Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
              child: Text(
                card.name,
                style: TextStyle(
                  color: canPlay ? Colors.white : const Color(0xFF888899),
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                ),
                maxLines: 2,
                textAlign: TextAlign.center,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            // 説明（非コンパクトのみ）
            if (!compact) ...[
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Text(
                  card.description,
                  style: const TextStyle(
                    color: Color(0xFF666688),
                    fontSize: 9,
                  ),
                  maxLines: 2,
                  textAlign: TextAlign.center,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
            const SizedBox(height: 4),
            // ATK/DEF/SPL
            Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (card.attack > 0)
                    _StatChip('ATK', card.attack, const Color(0xFFFF4444)),
                  if (card.attack > 0 && card.defense > 0)
                    const SizedBox(width: 4),
                  if (card.defense > 0)
                    _StatChip('DEF', card.defense, const Color(0xFF44AAFF)),
                  if (card.attack == 0 &&
                      card.defense == 0 &&
                      card.special > 0)
                    _StatChip('SPL', card.special, const Color(0xFFFFAA00)),
                ],
              ),
            ),
            // レアリティバー
            Container(
              height: 3,
              decoration: BoxDecoration(
                color: card.rarityColor.withValues(alpha: 0.8),
                borderRadius:
                    const BorderRadius.vertical(bottom: Radius.circular(8)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ===== カード詳細ダイアログ =====
class _CardDetailDialog extends StatelessWidget {
  final CardModel card;
  final String? actionLabel;
  final VoidCallback? onAction;
  const _CardDetailDialog({required this.card, this.actionLabel, this.onAction});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 320),
        decoration: BoxDecoration(
          color: const Color(0xFF0D1A2E),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
              color: card.typeColor.withValues(alpha: 0.8), width: 2),
          boxShadow: [
            BoxShadow(
                color: card.typeColor.withValues(alpha: 0.3),
                blurRadius: 20,
                spreadRadius: 2),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // ヘッダー
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: card.typeColor.withValues(alpha: 0.15),
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(14)),
              ),
              child: Row(
                children: [
                  // コストバッジ
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: const Color(0xFF001A3A),
                      border: Border.all(
                          color: const Color(0xFF00AAFF).withValues(alpha: 0.8),
                          width: 2),
                    ),
                    child: Center(
                      child: Text('${card.cost}',
                          style: const TextStyle(
                              color: Color(0xFF00AAFF),
                              fontSize: 16,
                              fontWeight: FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(card.name,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.5)),
                        const SizedBox(height: 2),
                        Row(
                          children: [
                            Text(card.typeIcon,
                                style: const TextStyle(fontSize: 12)),
                            const SizedBox(width: 4),
                            Text(
                              _typeLabel(card.type),
                              style: TextStyle(
                                  color: card.typeColor, fontSize: 11),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  // 閉じるボタン
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: const Icon(Icons.close,
                        color: Color(0xFF666688), size: 20),
                  ),
                ],
              ),
            ),

            // レアリティ
            Container(
              width: double.infinity,
              height: 4,
              color: card.rarityColor.withValues(alpha: 0.8),
            ),

            // 本文
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // レアリティバッジ
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: card.rarityColor.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                          color: card.rarityColor.withValues(alpha: 0.5)),
                    ),
                    child: Text(
                      '★ ${card.rarityLabel}',
                      style: TextStyle(
                          color: card.rarityColor,
                          fontSize: 11,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(height: 14),

                  // 効果説明
                  const Text('効果',
                      style: TextStyle(
                          color: Color(0xFF888899),
                          fontSize: 11,
                          letterSpacing: 1)),
                  const SizedBox(height: 6),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF080F1E),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                          color: card.typeColor.withValues(alpha: 0.2)),
                    ),
                    child: Text(
                      card.description,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          height: 1.6),
                    ),
                  ),

                  // ステータス行
                  if (card.attack > 0 || card.defense > 0 || card.special > 0) ...[
                    const SizedBox(height: 14),
                    const Text('ステータス',
                        style: TextStyle(
                            color: Color(0xFF888899),
                            fontSize: 11,
                            letterSpacing: 1)),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        if (card.attack > 0) ...[
                          _BigStat('⚡ ATK', card.attack, const Color(0xFFFF4444)),
                          const SizedBox(width: 10),
                        ],
                        if (card.defense > 0) ...[
                          _BigStat('🛡️ DEF', card.defense, const Color(0xFF44AAFF)),
                          const SizedBox(width: 10),
                        ],
                        if (card.special > 0) ...[
                          _BigStat('🔮 SPL', card.special, const Color(0xFFFFAA00)),
                        ],
                      ],
                    ),
                  ],

                  // エフェクトコード（デバッグ用・薄く）
                  if (card.effectCode.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    Text(
                      'EFFECT: ${card.effectCode}',
                      style: const TextStyle(
                          color: Color(0xFF2A2A4A),
                          fontSize: 9,
                          fontFamily: 'monospace'),
                    ),
                  ],
                ],
              ),
            ),

            // フッター
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: const BoxDecoration(
                color: Color(0xFF080F1E),
                borderRadius: BorderRadius.vertical(bottom: Radius.circular(14)),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    'MANA COST: ${card.cost}',
                    style: const TextStyle(
                        color: Color(0xFF00AAFF),
                        fontSize: 12,
                        fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  if (actionLabel != null && onAction != null) ...[
                    ElevatedButton(
                      onPressed: onAction,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: card.typeColor,
                        foregroundColor: Colors.black,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 10),
                      ),
                      child: Text(
                        actionLabel!,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 13),
                      ),
                    ),
                    const SizedBox(height: 4),
                  ],
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('閉じる',
                        style: TextStyle(color: Color(0xFF888899))),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _typeLabel(CardType type) {
    switch (type) {
      case CardType.attack:  return 'アタック';
      case CardType.defense: return 'ディフェンス';
      case CardType.special: return 'スペシャル';
      case CardType.exploit: return 'エクスプロイト';
    }
  }
}

class _BigStat extends StatelessWidget {
  final String label;
  final int value;
  final Color color;
  const _BigStat(this.label, this.value, this.color);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withValues(alpha: 0.4)),
      ),
      child: Column(
        children: [
          Text(label,
              style: TextStyle(
                  color: color, fontSize: 10, fontWeight: FontWeight.bold)),
          const SizedBox(height: 2),
          Text('$value',
              style: TextStyle(
                  color: color,
                  fontSize: 20,
                  fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final int value;
  final Color color;

  const _StatChip(this.label, this.value, this.color);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withValues(alpha: 0.4)),
      ),
      child: Text(
        '$label:$value',
        style: TextStyle(
          color: color,
          fontSize: 9,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}

// ===== カード詳細を直接呼べるグローバルヘルパー =====
void showCardDetail(BuildContext context, CardModel card) {
  showDialog(
    context: context,
    builder: (_) => _CardDetailDialog(card: card),
  );
}

/// 「使用」ボタン付きカード詳細ダイアログ
/// [canUse] が true のとき「使用」ボタンが有効
/// [onUse] が呼ばれたらダイアログは自動で閉じる
void showCardDetailWithAction({
  required BuildContext context,
  required CardModel card,
  required bool canUse,
  required VoidCallback onUse,
}) {
  showDialog(
    context: context,
    builder: (ctx) => _CardDetailDialog(
      card: card,
      actionLabel: canUse ? '⚡ 使用する' : null,
      onAction: canUse ? () { Navigator.pop(ctx); onUse(); } : null,
    ),
  );
}
