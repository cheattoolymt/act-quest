import 'dart:math';
import 'package:flutter/foundation.dart';
import '../models/card_model.dart';
import '../models/game_models.dart';

enum BattleResult { ongoing, playerWin, playerLose, draw }
enum Difficulty { easy, normal, hard }

class BattleLog {
  final String message;
  final bool isPlayerAction;
  BattleLog(this.message, {this.isPlayerAction = true});
}

class BattleState extends ChangeNotifier {
  PlayerState player;
  PlayerState enemy;
  int turnNumber = 1;
  bool isPlayerTurn = true;
  BattleResult result = BattleResult.ongoing;
  List<BattleLog> logs = [];
  Difficulty difficulty;
  bool isAiThinking = false;
  bool noPlayerDamageTaken = true;
  bool _disposed = false;

  static const int maxTurns = 20;

  int get currentMaxMana => min(turnNumber + 2, 10);

  BattleState({
    required this.player,
    required this.enemy,
    required this.difficulty,
  });

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  void addLog(String msg, {bool isPlayer = true}) {
    logs.add(BattleLog(msg, isPlayerAction: isPlayer));
    if (logs.length > 200) logs.removeAt(0);
    _notify();
  }

  void startBattle() {
    _shuffleDeck(player);
    _shuffleDeck(enemy);
    _drawCards(player, 5);
    _drawCards(enemy, 5);
    player.mana = currentMaxMana;
    enemy.mana = currentMaxMana;
    addLog('⚔️ バトル開始！ターン$turnNumber', isPlayer: true);
    _notify();
  }

  void _shuffleDeck(PlayerState p) {
    p.deck.shuffle(Random());
  }

  void _drawCards(PlayerState p, int count) {
    for (int i = 0; i < count; i++) {
      if (p.deck.isEmpty) {
        if (p.graveyard.isEmpty) break;
        p.deck = List.from(p.graveyard);
        p.graveyard.clear();
        _shuffleDeck(p);
      }
      if (p.deck.isEmpty) break;
      p.hand.add(p.deck.removeAt(0));
    }
  }

  bool playCard(String cardId) {
    if (!isPlayerTurn || result != BattleResult.ongoing) return false;
    final card = CardDatabase.getById(cardId);
    if (card == null || !player.hand.contains(cardId)) return false;

    int actualCost = card.cost;
    if (player.costReduceNext) {
      actualCost = (actualCost - 1).clamp(0, 99);
      player.costReduceNext = false;
    }
    if (player.mana < actualCost) return false;

    player.hand.remove(cardId);
    player.graveyard.add(cardId);
    player.mana -= actualCost;

    _applyCardEffect(card, player, enemy);
    addLog('${player.name}: 「${card.name}」を使用！', isPlayer: true);
    _checkWinCondition();
    _notify();
    return true;
  }

  void endPlayerTurn() {
    if (!isPlayerTurn || result != BattleResult.ongoing) return;
    isPlayerTurn = false;
    addLog('--- 敵のターン ---', isPlayer: false);
    _notify();
  }

  Future<void> processAiTurn() async {
    if (isPlayerTurn || result != BattleResult.ongoing) return;
    isAiThinking = true;
    _notify();

    await Future.delayed(const Duration(milliseconds: 800));
    if (_disposed) return;

    _processTurnStart(enemy, player);
    if (result != BattleResult.ongoing) { isAiThinking = false; _notify(); return; }

    if (!enemy.skipNextDraw) {
      _drawCards(enemy, 1);
    } else {
      enemy.skipNextDraw = false;
    }

    int mana = currentMaxMana + enemy.manaBoostNext;
    enemy.manaBoostNext = 0;
    enemy.mana = mana;

    final selectedCards = _aiSelectCards();
    for (final cardId in selectedCards) {
      if (result != BattleResult.ongoing || _disposed) break;
      final card = CardDatabase.getById(cardId);
      if (card == null || !enemy.hand.contains(cardId)) continue;
      int cost = card.cost;
      if (enemy.costReduceNext) { cost = (cost - 1).clamp(0, 99); enemy.costReduceNext = false; }
      if (enemy.mana < cost) continue;

      enemy.hand.remove(cardId);
      enemy.graveyard.add(cardId);
      enemy.mana -= cost;

      _applyCardEffect(card, enemy, player);
      addLog('${enemy.name}: 「${card.name}」を使用！', isPlayer: false);
      await Future.delayed(const Duration(milliseconds: 500));
      _checkWinCondition();
      _notify();
    }

    if (!_disposed && result == BattleResult.ongoing) {
      turnNumber++;
      isPlayerTurn = true;
      isAiThinking = false;
      _processTurnStart(player, enemy);
      if (!player.skipNextDraw) {
        _drawCards(player, 1);
      } else {
        player.skipNextDraw = false;
      }
      player.mana = currentMaxMana + player.manaBoostNext;
      player.manaBoostNext = 0;
      addLog('--- ターン$turnNumber あなたのターン ---', isPlayer: true);
    } else {
      isAiThinking = false;
    }
    _notify();
  }

  void _processTurnStart(PlayerState active, PlayerState opponent) {
    // エアギャップ
    if (active.airgapTurns > 0) {
      active.airgapTurns--;
      if (active.airgapTurns <= 0) active.airgapActive = false;
      addLog('🔒 ${active.name}はエアギャップ中（残${active.airgapTurns}T）', isPlayer: active == player);
    }
    // トロイの木馬ダメージ
    if (active.trojanTurns > 0) {
      active.trojanTurns--;
      _dealDamage(active, opponent, 6);
      addLog('🐴 トロイの木馬が爆発！${active.name}に6ダメージ！', isPlayer: active == player);
    }
    // 毒ダメージ
    if (active.poisonTurns > 0) {
      active.poisonTurns--;
      if (!active.airgapActive) {
        _rawDamage(active, 2);
        addLog('☠️ ${active.name}が毒で2ダメージ！', isPlayer: active == player);
      }
    }
    // シールド再生
    if (active.regenShieldTurns > 0) {
      active.regenShieldTurns--;
      active.shield += 2;
      addLog('🛡️ ${active.name}のシールドが2再生！', isPlayer: active == player);
    }
  }

  void _rawDamage(PlayerState target, int dmg) {
    if (target.airgapActive) return;
    target.hp = max(0, target.hp - dmg);
    if (target == player) noPlayerDamageTaken = false;
  }

  void _applyCardEffect(CardModel card, PlayerState user, PlayerState target) {
    // amplifyNext（プリビレッジエスカレーション）
    final amplify = user.amplifyNext;
    if (amplify) user.amplifyNext = false;

    int atk = amplify ? (card.attack * 1.5).round() : card.attack;
    int def = amplify ? (card.defense * 1.5).round() : card.defense;
    int spl = amplify ? (card.special * 1.5).round() : card.special;

    switch (card.effectCode) {
      case 'DAMAGE':
        _dealDamage(target, user, atk);
        break;

      case 'DAMAGE_TWICE':
        _dealDamage(target, user, (atk / 2).round());
        _dealDamage(target, user, (atk / 2).round());
        break;

      case 'DAMAGE_QUAD':
        for (int i = 0; i < 4; i++) _dealDamage(target, user, (atk / 4).round());
        break;

      case 'SPAM':
        for (int i = 0; i < 10; i++) _dealDamage(target, user, 1);
        addLog('📨 スパム×10！', isPlayer: user == player);
        break;

      case 'DAMAGE_DISCARD':
        _dealDamage(target, user, atk);
        _discardRandom(target, 1, user);
        break;

      case 'PIERCE':
        if (!target.airgapActive) {
          int dmg = atk;
          if (difficulty == Difficulty.easy && target == player) dmg = (dmg * 0.7).round();
          if (difficulty == Difficulty.hard && target == player) dmg = (dmg * 1.2).round();
          _rawDamage(target, dmg);
          addLog('🔴 シールド無視！${target.name}に${dmg}ダメージ！', isPlayer: user == player);
        }
        break;

      case 'DAMAGE_NEXT':
        _dealDamage(target, user, atk);
        user.manaBoostNext = 1;
        addLog('⚡ 次ターン追加攻撃！', isPlayer: user == player);
        break;

      case 'POISON':
        target.poisonTurns += 3;
        _dealDamage(target, user, atk);
        addLog('☠️ ${target.name}を毒状態に（3T）！', isPlayer: user == player);
        break;

      case 'SHIELD_BREAK':
        final removed = min(target.shield, 3);
        target.shield = max(0, target.shield - 3);
        _dealDamage(target, user, atk);
        addLog('💥 シールド${removed}消去＋${atk}ダメージ！', isPlayer: user == player);
        break;

      case 'SHIELD':
        user.shield += def;
        addLog('🛡️ ${user.name}がシールド${def}獲得！', isPlayer: user == player);
        break;

      case 'CLEANSE':
        user.poisonTurns = 0;
        user.trojanTurns = 0;
        user.shield += def;
        addLog('✨ 状態異常解除＋シールド${def}獲得！', isPlayer: user == player);
        break;

      case 'SHIELD_REDUCE':
        user.shield += def;
        user.blockNext = true; // 次の攻撃50%軽減を blockNextで代用
        addLog('🔒 シールド${def}獲得＋次攻撃軽減！', isPlayer: user == player);
        break;

      case 'BLOCK_NEXT':
        user.blockNext = true;
        addLog('🚫 次の攻撃を完全ブロック！', isPlayer: user == player);
        break;

      case 'REFLECT':
        user.reflectNext = true;
        user.shield += def;
        addLog('🔄 反射準備完了！シールド${def}！', isPlayer: user == player);
        break;

      case 'REGEN_SHIELD':
        user.shield += def;
        user.regenShieldTurns = 2;
        addLog('🛡️ AIシールド${def}！2ターン再生(+2/T)！', isPlayer: user == player);
        break;

      case 'IDS':
        user.shield += def;
        addLog('🔍 IDS/IPS起動！シールド${def}！', isPlayer: user == player);
        break;

      case 'AIRGAP':
        user.airgapActive = true;
        user.airgapTurns = 1;
        addLog('🔒 エアギャップ発動！1ターン完全無敵！', isPlayer: user == player);
        break;

      case 'PATCH':
        user.hp = min(user.hp + 5, user.maxHp);
        user.shield += def;
        addLog('💊 パッチ適用！HP+5 シールド+${def}！', isPlayer: user == player);
        break;

      case 'DOUBLE_SHIELD':
        user.shield = user.shield * 2;
        addLog('🛡️ ゼロトラスト！シールドが${user.shield}に倍増！', isPlayer: user == player);
        break;

      case 'WAF':
        user.shield += def;
        user.wafActive = true;
        addLog('🔒 WAF起動！シールド${def}＋次の攻撃カード無効！', isPlayer: user == player);
        break;

      case 'PEEK_DISCARD':
        _discardRandom(target, 1, user);
        break;

      case 'DRAW':
        _drawCards(user, spl);
        addLog('🃏 ${user.name}が${spl}枚ドロー！', isPlayer: user == player);
        break;

      case 'DRAW3':
        _drawCards(user, 3);
        addLog('🃏 ${user.name}が3枚ドロー！', isPlayer: user == player);
        break;

      case 'HEAL':
        user.poisonTurns = 0;
        user.hp = min(user.hp + spl, user.maxHp);
        addLog('💚 HP+${spl}回復！毒解除！', isPlayer: user == player);
        break;

      case 'MANA_BOOST':
        user.manaBoostNext += spl;
        addLog('⚡ 次ターンマナ+${spl}！', isPlayer: user == player);
        break;

      case 'MANA_FULL':
        user.mana = currentMaxMana;
        user.shield += 3;
        addLog('⚡ マナ全回復！シールド+3！', isPlayer: user == player);
        break;

      case 'PREDICT':
        user.predictActive = true;
        user.shield += 5;
        addLog('🤖 AI解析！シールド5＆次攻撃2倍！', isPlayer: user == player);
        break;

      case 'REVEAL_HAND':
        addLog('👁️ ${target.name}の手札を確認！(${target.hand.length}枚)', isPlayer: user == player);
        // 実際のUIは battle_screen で対応
        break;

      case 'COST_REDUCE':
        user.costReduceNext = true;
        addLog('🔧 次のカードのコスト-1！', isPlayer: user == player);
        break;

      case 'RECYCLE':
        if (user.graveyard.isNotEmpty) {
          final cardId = user.graveyard.removeLast();
          user.hand.add(cardId);
          final c = CardDatabase.getById(cardId);
          addLog('♻️ 「${c?.name ?? cardId}」を手札に戻した！', isPlayer: user == player);
        }
        break;

      case 'HALVE_SHIELD':
        target.shield = (target.shield / 2).floor();
        addLog('⚔️ ${target.name}のシールドを半分に！', isPlayer: user == player);
        break;

      case 'STEAL_MANA':
        final stolen = min(target.mana, spl);
        target.mana = max(0, target.mana - stolen);
        user.mana += stolen;
        addLog('💰 マナを${stolen}奪った！', isPlayer: user == player);
        break;

      case 'NULLIFY_TOP':
        if (target.deck.isNotEmpty) {
          final top = target.deck.removeAt(0);
          target.graveyard.add(top);
          addLog('❌ デッキ最上カードを無効化！', isPlayer: user == player);
        }
        break;

      case 'DESTROY_SHIELD':
        final oldShield = target.shield;
        target.shield = 0;
        _dealDamage(target, user, atk);
        addLog('💥 シールド${oldShield}破壊＋${atk}ダメ！', isPlayer: user == player);
        break;

      case 'DISCARD_TWO':
        _discardRandom(target, 2, user);
        break;

      case 'AMPLIFY_NEXT':
        user.amplifyNext = true;
        addLog('🚀 次のカード効果1.5倍！', isPlayer: user == player);
        break;

      case 'MEMORY_DUMP':
        _discardRandom(target, 2, user);
        addLog('💾 メモリダンプ！${target.name}の手札を2枚強制廃棄！', isPlayer: user == player);
        break;

      case 'MITM':
        user.mitmActive = true;
        _dealDamage(target, user, atk);
        addLog('🕵️ MITM攻撃！${atk}ダメ＋次の敵カードを4ダメに変換！', isPlayer: user == player);
        break;

      case 'TROJAN':
        _dealDamage(target, user, atk);
        target.trojanTurns = 1;
        addLog('🐴 トロイの木馬植え付け！次ターン6ダメ自動発火！', isPlayer: user == player);
        break;

      case 'APT':
        _dealDamage(target, user, atk);
        target.shield = max(0, target.shield - 2);
        addLog('🔍 APT侵入！${atk}ダメ＋シールド-2！', isPlayer: user == player);
        break;

      case 'FORKBOMB':
        _dealDamage(target, user, atk);
        _rawDamage(user, 2);
        addLog('💣 フォークボム！${atk}ダメ＋自分も2ダメ！', isPlayer: user == player);
        break;

      case 'DARK_RANDOM':
        final rng = Random();
        final randDmg = 8 + rng.nextInt(8);
        _dealDamage(target, user, randDmg);
        addLog('🌑 ダークウェブ購入！ランダム${randDmg}ダメ！', isPlayer: user == player);
        break;

      case 'DAMAGE_SKIP_DRAW':
        _dealDamage(target, user, atk);
        target.skipNextDraw = true;
        addLog('💉 XSS攻撃！${atk}ダメ＋次ターンドローなし！', isPlayer: user == player);
        break;
    }
    target.hp = max(0, target.hp);
    user.hp = max(0, user.hp);
  }

  void _discardRandom(PlayerState target, int count, PlayerState attacker) {
    for (int i = 0; i < count && target.hand.isNotEmpty; i++) {
      final idx = Random().nextInt(target.hand.length);
      final discarded = target.hand.removeAt(idx);
      target.graveyard.add(discarded);
      final dc = CardDatabase.getById(discarded);
      addLog('💨 ${target.name}の「${dc?.name ?? discarded}」が捨てられた！', isPlayer: attacker == player);
    }
  }

  void _dealDamage(PlayerState target, PlayerState attacker, int rawDmg) {
    if (target.airgapActive) {
      addLog('🔒 エアギャップで完全無効！', isPlayer: target == player);
      return;
    }

    int dmg = rawDmg;

    // WAFで攻撃カードを1回無効化
    if (target.wafActive) {
      target.wafActive = false;
      addLog('🔒 WAFが攻撃を無効化！', isPlayer: target == player);
      return;
    }

    // predictアクティブ（2倍攻撃）
    if (attacker.predictActive) {
      dmg *= 2;
      attacker.predictActive = false;
    }

    // ブロック
    if (target.blockNext) {
      target.blockNext = false;
      addLog('🚫 完全ブロック！ダメージ無効！', isPlayer: target == player);
      return;
    }

    // 反射
    if (target.reflectNext) {
      target.reflectNext = false;
      final reflectDmg = (dmg / 2).ceil();
      _rawDamage(attacker, reflectDmg);
      addLog('🔄 反射！攻撃者に${reflectDmg}ダメージ！', isPlayer: target == player);
      return;
    }

    // 難易度補正（プレイヤーが受けるダメージのみ）
    if (target == player) {
      if (difficulty == Difficulty.easy) dmg = (dmg * 0.7).round();
      if (difficulty == Difficulty.hard) dmg = (dmg * 1.2).round();
    }

    // シールド軽減
    if (target.shield > 0) {
      final absorbed = min(target.shield, dmg);
      target.shield -= absorbed;
      dmg -= absorbed;
      if (absorbed > 0) addLog('🛡️ シールドが${absorbed}吸収！', isPlayer: target == player);
    }

    if (dmg > 0) {
      _rawDamage(target, dmg);
      addLog('💥 ${target.name}に${dmg}ダメージ！（残HP: ${max(0, target.hp)}）', isPlayer: target != player);
    }
  }

  void _checkWinCondition() {
    if (player.hp <= 0 && enemy.hp <= 0) {
      result = BattleResult.draw;
      addLog('⚖️ 引き分け！', isPlayer: true);
    } else if (enemy.hp <= 0) {
      result = BattleResult.playerWin;
      addLog('🎉 ${player.name}の勝利！', isPlayer: true);
    } else if (player.hp <= 0) {
      result = BattleResult.playerLose;
      addLog('💀 ${enemy.name}の勝利... 敗北。', isPlayer: false);
    } else if (turnNumber > maxTurns) {
      // タイムアウト：残HPが多い方が勝ち
      if (player.hp > enemy.hp) {
        result = BattleResult.playerWin;
        addLog('⏰ ターン上限！HP有利で${player.name}の勝利！', isPlayer: true);
      } else if (enemy.hp > player.hp) {
        result = BattleResult.playerLose;
        addLog('⏰ ターン上限！HP有利で${enemy.name}の勝利...', isPlayer: false);
      } else {
        result = BattleResult.draw;
        addLog('⏰ ターン上限！引き分け！', isPlayer: true);
      }
    }
  }

  List<String> _aiSelectCards() {
    final playable = enemy.hand.where((id) {
      final c = CardDatabase.getById(id);
      if (c == null) return false;
      int cost = c.cost;
      if (enemy.costReduceNext) cost = (cost - 1).clamp(0, 99);
      return cost <= enemy.mana;
    }).toList();

    if (playable.isEmpty) return [];
    switch (difficulty) {
      case Difficulty.easy:   return _aiEasy(playable);
      case Difficulty.normal: return _aiNormal(playable);
      case Difficulty.hard:   return _aiHard(playable);
    }
  }

  List<String> _aiEasy(List<String> playable) {
    playable.shuffle();
    return playable.take(1).toList();
  }

  List<String> _aiNormal(List<String> playable) {
    final cards = playable.map((id) => CardDatabase.getById(id)!).toList();
    if (enemy.hp < 15) {
      final def = cards.where((c) => c.type == CardType.defense).toList();
      if (def.isNotEmpty) return [def.first.id];
    }
    cards.sort((a, b) => (b.attack + b.defense + b.special).compareTo(a.attack + a.defense + a.special));
    return [cards.first.id];
  }

  List<String> _aiHard(List<String> playable) {
    final cards = playable.map((id) => CardDatabase.getById(id)!).toList();
    List<CardModel> selected = [];
    int remaining = enemy.mana;

    void tryAdd(CardModel c) {
      int cost = c.cost;
      if (enemy.costReduceNext) cost = (cost - 1).clamp(0, 99);
      if (cost <= remaining && !selected.contains(c)) {
        selected.add(c);
        remaining -= cost;
        if (enemy.costReduceNext) enemy.costReduceNext = false;
      }
    }

    // 相手HPが低いなら即死狙い
    if (player.hp <= 12) {
      for (final c in cards.where((c) => c.effectCode == 'PIERCE' || c.effectCode == 'DESTROY_SHIELD')) {
        tryAdd(c);
      }
    }
    // シールド破壊
    if (player.shield > 6) {
      for (final c in cards.where((c) => ['SHIELD_BREAK','HALVE_SHIELD','DESTROY_SHIELD','APT'].contains(c.effectCode))) {
        tryAdd(c);
      }
    }
    // 自分HPが低いなら回復
    if (enemy.hp < 12) {
      for (final c in cards.where((c) => ['HEAL','SHIELD','REGEN_SHIELD','AIRGAP','PATCH'].contains(c.effectCode))) {
        tryAdd(c);
      }
    }
    // 毒・トロイ植え付け
    for (final c in cards.where((c) => ['POISON','TROJAN'].contains(c.effectCode))) {
      tryAdd(c);
    }
    // 残りマナで攻撃
    final atks = cards.where((c) => c.type == CardType.attack || c.type == CardType.exploit).toList();
    atks.sort((a, b) => b.attack.compareTo(a.attack));
    for (final c in atks) { tryAdd(c); }

    return selected.map((c) => c.id).toList();
  }
}
