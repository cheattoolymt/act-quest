import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/card_model.dart';
import '../models/game_models.dart';
import '../providers/game_provider.dart';
import 'stage_select_screen.dart';
import 'deck_edit_screen.dart';
import 'achievement_screen.dart';
import 'multiplayer_screen.dart';

class MainMenuScreen extends StatelessWidget {
  const MainMenuScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<GameProvider>(
      builder: (context, gp, _) {
        if (!gp.isLoaded) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        return Scaffold(
          body: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF000510), Color(0xFF0A0A1A), Color(0xFF010A05)],
              ),
            ),
            child: SafeArea(
              child: LayoutBuilder(
                builder: (context, constraints) {
                  return SingleChildScrollView(
                    physics: const ClampingScrollPhysics(),
                    child: ConstrainedBox(
                      constraints: BoxConstraints(minHeight: constraints.maxHeight),
                      child: IntrinsicHeight(
                        child: Column(
                          children: [
                            _buildHeader(context, gp),
                            const SizedBox(height: 12),
                            _buildTitle(gp),
                            const SizedBox(height: 16),
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 20),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    _MenuButton(
                                      icon: gp.playerRole == PlayerRole.white ? '🛡️' : '💀',
                                      label: 'SOLO BATTLE',
                                      subtitle: 'ステージモード vsAI',
                                      color: gp.playerRole == PlayerRole.white
                                          ? const Color(0xFF00FF88)
                                          : const Color(0xFFFF4444),
                                      onTap: () => Navigator.push(context,
                                          MaterialPageRoute(builder: (_) => const StageSelectScreen())),
                                    ),
                                    const SizedBox(height: 10),
                                    _ComingSoonButton(
                                      icon: '🌍',
                                      label: 'ONLINE BATTLE',
                                      subtitle: 'COMING SOON...',
                                    ),
                                    const SizedBox(height: 10),
                                    _MenuButton(
                                      icon: '📶',
                                      label: 'WiFi LOCAL BATTLE',
                                      subtitle: '同一WiFiでLAN対戦',
                                      color: const Color(0xFF8866FF),
                                      onTap: () => Navigator.push(context,
                                          MaterialPageRoute(builder: (_) => const MultiplayerScreen(mode: MultiplayerMode.wifi))),
                                    ),
                                    const SizedBox(height: 10),
                                    _MenuButton(
                                      icon: '🃏',
                                      label: 'DECK EDITOR',
                                      subtitle: 'デッキ編集 (${gp.unlockedCardIds.toSet().length}/${CardDatabase.allCards.length}枚解放)',
                                      color: const Color(0xFFFFAA00),
                                      onTap: () => Navigator.push(context,
                                          MaterialPageRoute(builder: (_) => const DeckEditScreen())),
                                    ),
                                    const SizedBox(height: 10),
                                    _MenuButton(
                                      icon: '🏆',
                                      label: 'ACHIEVEMENTS',
                                      subtitle: '${gp.earnedAchievementIds.length}/${AchievementDatabase.all.length} 達成',
                                      color: const Color(0xFFFF8844),
                                      onTap: () => Navigator.push(context,
                                          MaterialPageRoute(builder: (_) => const AchievementScreen())),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            _buildFooter(context, gp),
                            const SizedBox(height: 12),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildHeader(BuildContext context, GameProvider gp) {
    final xpPct = gp.xpForNextLevel > 0
        ? (gp.xpInLevel / gp.xpForNextLevel).clamp(0.0, 1.0)
        : 0.0;
    final isWhite = gp.playerRole == PlayerRole.white;

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF0F1A2E),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF1A3A5C)),
      ),
      child: Row(
        children: [
          // アバター（タップでロール切替）
          GestureDetector(
            onTap: () => _showRoleDialog(context, gp),
            child: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: isWhite ? const Color(0xFF00FF88) : const Color(0xFFFF4444),
                  width: 2,
                ),
                color: isWhite ? const Color(0xFF0A2A1A) : const Color(0xFF2A0A0A),
              ),
              child: Center(
                child: Text(
                  isWhite ? '👨‍💻' : '🦹',
                  style: const TextStyle(fontSize: 24),
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        gp.playerName,
                        style: TextStyle(
                          color: isWhite ? const Color(0xFF00FF88) : const Color(0xFFFF6666),
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                      decoration: BoxDecoration(
                        color: (isWhite ? const Color(0xFF00FF88) : const Color(0xFFFF4444))
                            .withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        'Lv.${gp.level}',
                        style: TextStyle(
                          color: isWhite ? const Color(0xFF00FF88) : const Color(0xFFFF6666),
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const SizedBox(width: 4),
                    // ロールバッジ
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                      decoration: BoxDecoration(
                        color: (isWhite ? const Color(0xFF00AAFF) : const Color(0xFFAA44FF))
                            .withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        isWhite ? 'WHITE' : 'BLACK',
                        style: TextStyle(
                          color: isWhite ? const Color(0xFF00AAFF) : const Color(0xFFAA44FF),
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: xpPct,
                    backgroundColor: const Color(0xFF1A3A5C),
                    color: isWhite ? const Color(0xFF00FF88) : const Color(0xFFFF6666),
                    minHeight: 5,
                  ),
                ),
                Text(
                  'XP: ${gp.xpInLevel}/${gp.xpForNextLevel}',
                  style: const TextStyle(color: Color(0xFF555577), fontSize: 9),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Column(
            children: [
              Text('${gp.totalWins}W',
                  style: const TextStyle(color: Color(0xFF00FF88), fontSize: 12, fontWeight: FontWeight.bold)),
              Text('${gp.totalLosses}L',
                  style: const TextStyle(color: Color(0xFFFF4444), fontSize: 12, fontWeight: FontWeight.bold)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTitle(GameProvider gp) {
    final isWhite = gp.playerRole == PlayerRole.white;
    return Column(
      children: [
        ShaderMask(
          shaderCallback: (bounds) => LinearGradient(
            colors: isWhite
                ? [const Color(0xFF00FF88), const Color(0xFF00AAFF)]
                : [const Color(0xFFFF4444), const Color(0xFFAA44FF)],
          ).createShader(bounds),
          child: const Text(
            'ACTION QUEST',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              letterSpacing: 3,
              color: Colors.white,
            ),
          ),
        ),
        Text(
          isWhite
              ? '⚡ WHITE HACKER vs BLACK HACKER ⚡'
              : '💀 BLACK HACKER MODE ACTIVE 💀',
          style: TextStyle(
            color: isWhite ? const Color(0xFF333355) : const Color(0xFF441122),
            fontSize: 10,
            letterSpacing: 1,
          ),
        ),
      ],
    );
  }

  Widget _buildFooter(BuildContext context, GameProvider gp) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'Cleared: ${gp.clearedStages.length}/${StageDatabase.stages.length}',
            style: const TextStyle(color: Color(0xFF444466), fontSize: 11),
          ),
          TextButton(
            onPressed: () => _showSettingsDialog(context, gp),
            child: const Text('⚙️ SETTINGS',
                style: TextStyle(color: Color(0xFF666666), fontSize: 11)),
          ),
        ],
      ),
    );
  }

  void _showRoleDialog(BuildContext context, GameProvider gp) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF0F1A2E),
        title: const Text('ロール選択', style: TextStyle(color: Colors.white, fontSize: 16)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('どちらのハッカーとしてプレイしますか？',
                style: TextStyle(color: Color(0xFF888899), fontSize: 12)),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () async {
                      await gp.setRole(PlayerRole.white);
                      if (context.mounted) Navigator.pop(context);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        color: gp.playerRole == PlayerRole.white
                            ? const Color(0xFF00FF88).withValues(alpha: 0.2)
                            : const Color(0xFF0A1A0A),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: gp.playerRole == PlayerRole.white
                              ? const Color(0xFF00FF88)
                              : const Color(0xFF1A3A1A),
                          width: gp.playerRole == PlayerRole.white ? 2 : 1,
                        ),
                      ),
                      child: Column(
                        children: [
                          const Text('👨‍💻', style: TextStyle(fontSize: 28)),
                          const SizedBox(height: 6),
                          const Text('WHITE HACKER',
                              style: TextStyle(
                                  color: Color(0xFF00FF88),
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold)),
                          const SizedBox(height: 2),
                          const Text('防衛・正義の味方',
                              style: TextStyle(color: Color(0xFF555577), fontSize: 9)),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: GestureDetector(
                    onTap: () async {
                      await gp.setRole(PlayerRole.black);
                      if (context.mounted) Navigator.pop(context);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        color: gp.playerRole == PlayerRole.black
                            ? const Color(0xFFFF4444).withValues(alpha: 0.2)
                            : const Color(0xFF1A0A0A),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: gp.playerRole == PlayerRole.black
                              ? const Color(0xFFFF4444)
                              : const Color(0xFF3A1A1A),
                          width: gp.playerRole == PlayerRole.black ? 2 : 1,
                        ),
                      ),
                      child: Column(
                        children: [
                          const Text('🦹', style: TextStyle(fontSize: 28)),
                          const SizedBox(height: 6),
                          const Text('BLACK HACKER',
                              style: TextStyle(
                                  color: Color(0xFFFF6666),
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold)),
                          const SizedBox(height: 2),
                          const Text('攻撃・ダークサイド',
                              style: TextStyle(color: Color(0xFF553333), fontSize: 9)),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('閉じる', style: TextStyle(color: Color(0xFF666666))),
          ),
        ],
      ),
    );
  }

  void _showSettingsDialog(BuildContext context, GameProvider gp) {
    final nameCtrl = TextEditingController(text: gp.playerName);
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setDialogState) {
          final isWhite = gp.playerRole == PlayerRole.white;
          return AlertDialog(
            backgroundColor: const Color(0xFF0F1A2E),
            title: const Text('設定', style: TextStyle(color: Color(0xFF00FF88))),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // プレイヤー名
                TextField(
                  controller: nameCtrl,
                  style: const TextStyle(color: Colors.white),
                  maxLength: 16,
                  decoration: const InputDecoration(
                    labelText: 'プレイヤー名',
                    labelStyle: TextStyle(color: Color(0xFF666666)),
                    counterStyle: TextStyle(color: Color(0xFF444466)),
                    enabledBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Color(0xFF1A3A5C))),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Color(0xFF00FF88))),
                  ),
                ),
                const SizedBox(height: 20),
                // ロール選択
                const Text(
                  'ハッカーロール',
                  style: TextStyle(color: Color(0xFF666666), fontSize: 11),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    // ホワイトハット
                    Expanded(
                      child: GestureDetector(
                        onTap: () async {
                          await gp.setRole(PlayerRole.white);
                          setDialogState(() {});
                        },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            color: isWhite
                                ? const Color(0xFF00AAFF).withValues(alpha: 0.15)
                                : const Color(0xFF080812),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: isWhite
                                  ? const Color(0xFF00AAFF)
                                  : const Color(0xFF1A2A3A),
                              width: isWhite ? 2 : 1,
                            ),
                          ),
                          child: Column(
                            children: [
                              Text('🛡️',
                                  style: TextStyle(
                                      fontSize: isWhite ? 26 : 22)),
                              const SizedBox(height: 4),
                              Text(
                                'ホワイトハット',
                                style: TextStyle(
                                  color: isWhite
                                      ? const Color(0xFF00AAFF)
                                      : const Color(0xFF555577),
                                  fontSize: 10,
                                  fontWeight: isWhite
                                      ? FontWeight.bold
                                      : FontWeight.normal,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    // ブラックハット
                    Expanded(
                      child: GestureDetector(
                        onTap: () async {
                          await gp.setRole(PlayerRole.black);
                          setDialogState(() {});
                        },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            color: !isWhite
                                ? const Color(0xFFFF4444).withValues(alpha: 0.12)
                                : const Color(0xFF080812),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: !isWhite
                                  ? const Color(0xFFFF4444)
                                  : const Color(0xFF1A2A3A),
                              width: !isWhite ? 2 : 1,
                            ),
                          ),
                          child: Column(
                            children: [
                              Text('💀',
                                  style: TextStyle(
                                      fontSize: !isWhite ? 26 : 22)),
                              const SizedBox(height: 4),
                              Text(
                                'ブラックハット',
                                style: TextStyle(
                                  color: !isWhite
                                      ? const Color(0xFFFF4444)
                                      : const Color(0xFF555577),
                                  fontSize: 10,
                                  fontWeight: !isWhite
                                      ? FontWeight.bold
                                      : FontWeight.normal,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  isWhite
                      ? '🛡️ ソロ対戦では相手はブラックハット'
                      : '💀 ソロ対戦では相手はホワイトハット',
                  style: TextStyle(
                    color: isWhite
                        ? const Color(0xFF00AAFF).withValues(alpha: 0.7)
                        : const Color(0xFFFF4444).withValues(alpha: 0.7),
                    fontSize: 10,
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('キャンセル', style: TextStyle(color: Color(0xFF666666))),
              ),
              TextButton(
                onPressed: () async {
                  if (nameCtrl.text.trim().isNotEmpty) {
                    await gp.updateName(nameCtrl.text.trim());
                  }
                  if (context.mounted) Navigator.pop(context);
                },
                child: const Text('保存', style: TextStyle(color: Color(0xFF00FF88))),
              ),
              TextButton(
                onPressed: () => _confirmReset(context, gp),
                child: const Text('リセット', style: TextStyle(color: Color(0xFFFF4444))),
              ),
            ],
          );
        },
      ),
    );
  }

  void _confirmReset(BuildContext context, GameProvider gp) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF0F1A2E),
        title: const Text('データリセット', style: TextStyle(color: Color(0xFFFF4444))),
        content: const Text('全データを削除します。よろしいですか？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('キャンセル'),
          ),
          TextButton(
            onPressed: () async {
              await gp.resetSave();
              if (context.mounted) {
                Navigator.pop(context);
                Navigator.pop(context);
              }
            },
            child: const Text('リセット', style: TextStyle(color: Color(0xFFFF4444))),
          ),
        ],
      ),
    );
  }
}

class _ComingSoonButton extends StatelessWidget {
  final String icon;
  final String label;
  final String subtitle;

  const _ComingSoonButton({
    required this.icon,
    required this.label,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: 0.45,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF0F1A2E),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFF333355)),
        ),
        child: Row(
          children: [
            Text(icon, style: const TextStyle(fontSize: 22)),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                      style: const TextStyle(
                          color: Color(0xFF555577),
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.2)),
                  Text(subtitle,
                      style: const TextStyle(
                          color: Color(0xFF444466),
                          fontSize: 10,
                          fontStyle: FontStyle.italic)),
                ],
              ),
            ),
            const Icon(Icons.lock_outline, color: Color(0xFF333355), size: 16),
          ],
        ),
      ),
    );
  }
}

class _MenuButton extends StatelessWidget {
  final String icon;
  final String label;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const _MenuButton({
    required this.icon, required this.label,
    required this.subtitle, required this.color, required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF0F1A2E),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withValues(alpha: 0.4)),
          boxShadow: [BoxShadow(color: color.withValues(alpha: 0.08), blurRadius: 6)],
        ),
        child: Row(
          children: [
            Text(icon, style: const TextStyle(fontSize: 22)),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                      style: TextStyle(
                          color: color,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.2)),
                  Text(subtitle,
                      style: const TextStyle(color: Color(0xFF555577), fontSize: 10)),
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: color.withValues(alpha: 0.5), size: 18),
          ],
        ),
      ),
    );
  }
}
