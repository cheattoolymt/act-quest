import 'package:flutter/material.dart';

enum CardType {
  attack,   // 攻撃系ハッキングツール
  defense,  // 防御系ファイアウォール
  special,  // 特殊効果
  exploit,  // バグ悪用
}

enum CardRarity {
  common,
  uncommon,
  rare,
  legendary,
}

class CardModel {
  final String id;
  final String name;
  final String description;
  final CardType type;
  final CardRarity rarity;
  final int cost;
  final int attack;
  final int defense;
  final int special;
  final String effectCode;

  const CardModel({
    required this.id,
    required this.name,
    required this.description,
    required this.type,
    required this.rarity,
    required this.cost,
    this.attack = 0,
    this.defense = 0,
    this.special = 0,
    this.effectCode = '',
  });

  Color get typeColor {
    switch (type) {
      case CardType.attack:  return const Color(0xFFFF4444);
      case CardType.defense: return const Color(0xFF44AAFF);
      case CardType.special: return const Color(0xFFFFAA00);
      case CardType.exploit: return const Color(0xFFAA44FF);
    }
  }

  Color get rarityColor {
    switch (rarity) {
      case CardRarity.common:    return Colors.grey;
      case CardRarity.uncommon:  return Colors.green;
      case CardRarity.rare:      return Colors.blue;
      case CardRarity.legendary: return Colors.orange;
    }
  }

  String get typeIcon {
    switch (type) {
      case CardType.attack:  return '⚡';
      case CardType.defense: return '🛡️';
      case CardType.special: return '🔮';
      case CardType.exploit: return '💀';
    }
  }

  String get rarityLabel {
    switch (rarity) {
      case CardRarity.common:    return 'COMMON';
      case CardRarity.uncommon:  return 'UNCOMMON';
      case CardRarity.rare:      return 'RARE';
      case CardRarity.legendary: return 'LEGENDARY';
    }
  }

  Map<String, dynamic> toJson() => {
    'id': id, 'name': name, 'description': description,
    'type': type.index, 'rarity': rarity.index, 'cost': cost,
    'attack': attack, 'defense': defense, 'special': special, 'effectCode': effectCode,
  };

  factory CardModel.fromJson(Map<String, dynamic> json) => CardModel(
    id: json['id'], name: json['name'], description: json['description'],
    type: CardType.values[json['type']], rarity: CardRarity.values[json['rarity']],
    cost: json['cost'], attack: json['attack'] ?? 0,
    defense: json['defense'] ?? 0, special: json['special'] ?? 0,
    effectCode: json['effectCode'] ?? '',
  );
}

// ===== 全カードデータベース（45枚） =====
class CardDatabase {
  static const List<CardModel> allCards = [

    // ===== ATTACK (16枚) =====
    CardModel(id: 'atk_001', name: 'SQLインジェクション',
      description: 'DBに侵入。5ダメージ。',
      type: CardType.attack, rarity: CardRarity.common, cost: 2, attack: 5, effectCode: 'DAMAGE'),
    CardModel(id: 'atk_002', name: 'DDoS攻撃',
      description: '3ダメージ×2回。',
      type: CardType.attack, rarity: CardRarity.common, cost: 3, attack: 6, effectCode: 'DAMAGE_TWICE'),
    CardModel(id: 'atk_003', name: 'フィッシング',
      description: '相手手札1枚捨て＋3ダメージ。',
      type: CardType.attack, rarity: CardRarity.uncommon, cost: 3, attack: 3, effectCode: 'DAMAGE_DISCARD'),
    CardModel(id: 'atk_004', name: 'ランサムウェア',
      description: 'シールド無視8ダメージ。',
      type: CardType.attack, rarity: CardRarity.rare, cost: 5, attack: 8, effectCode: 'PIERCE'),
    CardModel(id: 'atk_005', name: 'ゼロデイ攻撃',
      description: '未知の脆弱性。12ダメージ。',
      type: CardType.attack, rarity: CardRarity.legendary, cost: 7, attack: 12, effectCode: 'DAMAGE'),
    CardModel(id: 'atk_006', name: 'パスワードクラック',
      description: '4ダメージ＋次ターン追加攻撃。',
      type: CardType.attack, rarity: CardRarity.uncommon, cost: 3, attack: 4, effectCode: 'DAMAGE_NEXT'),
    CardModel(id: 'atk_007', name: 'マルウェア注入',
      description: '毒3ターン(毎ターン2ダメ)。',
      type: CardType.attack, rarity: CardRarity.uncommon, cost: 4, attack: 2, effectCode: 'POISON'),
    CardModel(id: 'atk_008', name: 'バッファオーバーフロー',
      description: 'シールド3消去＋5ダメージ。',
      type: CardType.attack, rarity: CardRarity.rare, cost: 4, attack: 5, effectCode: 'SHIELD_BREAK'),
    CardModel(id: 'atk_009', name: 'ブルートフォース',
      description: '2ダメージ×4回。',
      type: CardType.attack, rarity: CardRarity.uncommon, cost: 4, attack: 8, effectCode: 'DAMAGE_QUAD'),
    CardModel(id: 'atk_010', name: 'XSS攻撃',
      description: '6ダメージ。相手は1枚引けない。',
      type: CardType.attack, rarity: CardRarity.uncommon, cost: 3, attack: 6, effectCode: 'DAMAGE_SKIP_DRAW'),
    CardModel(id: 'atk_011', name: 'MITMアタック',
      description: '次の相手カードを4ダメに変換。',
      type: CardType.attack, rarity: CardRarity.rare, cost: 4, attack: 4, effectCode: 'MITM'),
    CardModel(id: 'atk_012', name: 'トロイの木馬',
      description: '今は3ダメ。次ターン自動6ダメ。',
      type: CardType.attack, rarity: CardRarity.rare, cost: 5, attack: 3, effectCode: 'TROJAN'),
    CardModel(id: 'atk_013', name: 'スパムフラッド',
      description: '1ダメージ×10回。',
      type: CardType.attack, rarity: CardRarity.common, cost: 3, attack: 10, effectCode: 'SPAM'),
    CardModel(id: 'atk_014', name: 'APT侵入',
      description: '7ダメージ。相手シールド2消去。',
      type: CardType.attack, rarity: CardRarity.rare, cost: 5, attack: 7, effectCode: 'APT'),
    CardModel(id: 'atk_015', name: 'フォークボム',
      description: 'CPU過負荷。10ダメージ。自分2ダメ。',
      type: CardType.attack, rarity: CardRarity.legendary, cost: 6, attack: 10, effectCode: 'FORKBOMB'),
    CardModel(id: 'atk_016', name: 'ダークウェブ購入',
      description: 'ランダム強力攻撃(8〜15)。',
      type: CardType.attack, rarity: CardRarity.legendary, cost: 8, attack: 12, effectCode: 'DARK_RANDOM'),

    // ===== DEFENSE (12枚) =====
    CardModel(id: 'def_001', name: 'ファイアウォール',
      description: 'シールド5獲得。',
      type: CardType.defense, rarity: CardRarity.common, cost: 2, defense: 5, effectCode: 'SHIELD'),
    CardModel(id: 'def_002', name: 'アンチウイルス',
      description: '毒解除＋シールド3。',
      type: CardType.defense, rarity: CardRarity.common, cost: 2, defense: 3, effectCode: 'CLEANSE'),
    CardModel(id: 'def_003', name: 'VPN暗号化',
      description: 'シールド8。次の攻撃50%軽減。',
      type: CardType.defense, rarity: CardRarity.uncommon, cost: 3, defense: 8, effectCode: 'SHIELD_REDUCE'),
    CardModel(id: 'def_004', name: '二段階認証',
      description: '次の攻撃完全ブロック。',
      type: CardType.defense, rarity: CardRarity.rare, cost: 4, effectCode: 'BLOCK_NEXT'),
    CardModel(id: 'def_005', name: 'ハニーポット',
      description: '攻撃を誘い込み、3ダメ反射。',
      type: CardType.defense, rarity: CardRarity.rare, cost: 3, defense: 3, effectCode: 'REFLECT'),
    CardModel(id: 'def_006', name: 'AIセキュリティ',
      description: 'シールド6＋次ターン3再生。',
      type: CardType.defense, rarity: CardRarity.legendary, cost: 6, defense: 6, effectCode: 'REGEN_SHIELD'),
    CardModel(id: 'def_007', name: 'IDS/IPS',
      description: 'シールド4。次の攻撃カードを検知して+2シールド。',
      type: CardType.defense, rarity: CardRarity.uncommon, cost: 3, defense: 4, effectCode: 'IDS'),
    CardModel(id: 'def_008', name: 'エアギャップ',
      description: '1ターン完全無敵。コスト高。',
      type: CardType.defense, rarity: CardRarity.legendary, cost: 8, effectCode: 'AIRGAP'),
    CardModel(id: 'def_009', name: 'パッチ適用',
      description: 'HP5回復＋シールド2。',
      type: CardType.defense, rarity: CardRarity.common, cost: 2, defense: 2, effectCode: 'PATCH'),
    CardModel(id: 'def_010', name: 'DMZ設置',
      description: 'シールド7獲得。',
      type: CardType.defense, rarity: CardRarity.uncommon, cost: 3, defense: 7, effectCode: 'SHIELD'),
    CardModel(id: 'def_011', name: 'ゼロトラスト',
      description: '全シールドを倍にする。',
      type: CardType.defense, rarity: CardRarity.legendary, cost: 6, effectCode: 'DOUBLE_SHIELD'),
    CardModel(id: 'def_012', name: 'WAF',
      description: 'シールド4。攻撃系カードを1枚無効化。',
      type: CardType.defense, rarity: CardRarity.rare, cost: 4, defense: 4, effectCode: 'WAF'),

    // ===== SPECIAL (10枚) =====
    CardModel(id: 'spc_001', name: 'ソーシャルエンジニアリング',
      description: '相手手札1枚を選んで捨てさせる。',
      type: CardType.special, rarity: CardRarity.uncommon, cost: 3, special: 1, effectCode: 'PEEK_DISCARD'),
    CardModel(id: 'spc_002', name: 'バックドア',
      description: '2枚ドロー。',
      type: CardType.special, rarity: CardRarity.common, cost: 2, special: 2, effectCode: 'DRAW'),
    CardModel(id: 'spc_003', name: 'システムリブート',
      description: 'HP5回復＋毒解除。',
      type: CardType.special, rarity: CardRarity.uncommon, cost: 3, special: 5, effectCode: 'HEAL'),
    CardModel(id: 'spc_004', name: 'ネットワーク盗聴',
      description: '次のターンマナ+2。',
      type: CardType.special, rarity: CardRarity.uncommon, cost: 2, special: 2, effectCode: 'MANA_BOOST'),
    CardModel(id: 'spc_005', name: 'AI解析',
      description: 'シールド5＋次の攻撃2倍。',
      type: CardType.special, rarity: CardRarity.legendary, cost: 6, special: 10, effectCode: 'PREDICT'),
    CardModel(id: 'spc_006', name: '情報漏洩',
      description: '相手の手札を全部見る。',
      type: CardType.special, rarity: CardRarity.rare, cost: 3, effectCode: 'REVEAL_HAND'),
    CardModel(id: 'spc_007', name: 'デバッグ',
      description: '3枚ドロー。コスト軽め。',
      type: CardType.special, rarity: CardRarity.uncommon, cost: 3, special: 3, effectCode: 'DRAW3'),
    CardModel(id: 'spc_008', name: 'ホワイトハット切替',
      description: 'マナ全回復＋シールド3。',
      type: CardType.special, rarity: CardRarity.rare, cost: 4, special: 3, effectCode: 'MANA_FULL'),
    CardModel(id: 'spc_009', name: 'レッドチーム演習',
      description: '次のターン全カードコスト-1。',
      type: CardType.special, rarity: CardRarity.rare, cost: 3, effectCode: 'COST_REDUCE'),
    CardModel(id: 'spc_010', name: 'フォレンジック解析',
      description: '墓地から1枚手札に戻す。',
      type: CardType.special, rarity: CardRarity.uncommon, cost: 3, effectCode: 'RECYCLE'),

    // ===== EXPLOIT (7枚) =====
    CardModel(id: 'exp_001', name: 'ルートキット',
      description: '相手シールドを半分に。',
      type: CardType.exploit, rarity: CardRarity.rare, cost: 4, effectCode: 'HALVE_SHIELD'),
    CardModel(id: 'exp_002', name: 'クリプトジャック',
      description: '相手からマナ1奪う。',
      type: CardType.exploit, rarity: CardRarity.uncommon, cost: 2, special: 1, effectCode: 'STEAL_MANA'),
    CardModel(id: 'exp_003', name: 'データ改ざん',
      description: '相手デッキ最上カードを無効化。',
      type: CardType.exploit, rarity: CardRarity.rare, cost: 4, effectCode: 'NULLIFY_TOP'),
    CardModel(id: 'exp_004', name: 'カーネルパニック',
      description: '全シールド破壊＋10ダメージ。',
      type: CardType.exploit, rarity: CardRarity.legendary, cost: 8, attack: 10, effectCode: 'DESTROY_SHIELD'),
    CardModel(id: 'exp_005', name: 'リバースシェル',
      description: '相手の手札2枚をランダムで捨てさせる。',
      type: CardType.exploit, rarity: CardRarity.rare, cost: 5, effectCode: 'DISCARD_TWO'),
    CardModel(id: 'exp_006', name: 'プリビレッジエスカレーション',
      description: '次に使うカードの効果を1.5倍。',
      type: CardType.exploit, rarity: CardRarity.legendary, cost: 5, effectCode: 'AMPLIFY_NEXT'),
    CardModel(id: 'exp_007', name: 'メモリダンプ',
      description: '相手の全手札を見てその中から2枚捨てさせる。',
      type: CardType.exploit, rarity: CardRarity.legendary, cost: 7, effectCode: 'MEMORY_DUMP'),
  ];

  static CardModel? getById(String id) {
    try { return allCards.firstWhere((c) => c.id == id); } catch (_) { return null; }
  }

  // スターターデッキ（20枚）
  static List<String> get starterDeckIds => [
    'atk_001', 'atk_001', 'atk_002', 'atk_002',
    'atk_006', 'atk_013',
    'def_001', 'def_001', 'def_002', 'def_002',
    'def_009', 'def_010',
    'spc_002', 'spc_002', 'spc_003', 'spc_004',
    'exp_002',
    'atk_003', 'def_003', 'spc_007',
  ];

  // アンロック順
  static List<String> get unlockOrder => [
    'atk_001','def_001','spc_002',
    'atk_002','def_002','atk_006',
    'spc_003','spc_004','atk_003',
    'def_003','exp_002','atk_007',
    'atk_008','atk_009','def_004',
    'def_005','def_007','exp_001',
    'spc_001','atk_010','atk_013',
    'def_009','def_010','spc_007',
    'atk_011','atk_012','spc_006',
    'spc_008','spc_009','spc_010',
    'def_011','def_012','exp_003',
    'exp_005','atk_014','atk_015',
    'exp_006','atk_004','def_008',
    'atk_016','exp_007','def_006',
    'spc_005','atk_005','exp_004',
  ];
}
