package com.actionquest.game

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

