enum GamePhase { draw, main, end }
enum PlayerRole { white, black }

class PlayerState {
  final String id;
  final String name;
  final PlayerRole role;
  int hp;
  int maxHp;
  int mana;
  int maxMana;
  int shield;
  List<String> deck;
  List<String> hand;
  List<String> graveyard;
  bool blockNext;
  bool reflectNext;
  int poisonTurns;
  int regenShieldTurns;
  int manaBoostNext;
  bool predictActive;
  bool airgapActive;      // エアギャップ（2ターン無敵）
  int airgapTurns;
  bool amplifyNext;       // プリビレッジエスカレーション
  bool costReduceNext;    // レッドチーム演習
  bool skipNextDraw;      // XSS攻撃で次ドロースキップ
  bool mitmActive;        // MITM攻撃
  int trojanTurns;        // トロイの木馬の残ターン
  bool wafActive;         // WAFアクティブ

  PlayerState({
    required this.id,
    required this.name,
    required this.role,
    this.hp = 30,
    this.maxHp = 30,
    this.mana = 0,
    this.maxMana = 10,
    this.shield = 0,
    List<String>? deck,
    List<String>? hand,
    List<String>? graveyard,
    this.blockNext = false,
    this.reflectNext = false,
    this.poisonTurns = 0,
    this.regenShieldTurns = 0,
    this.manaBoostNext = 0,
    this.predictActive = false,
    this.airgapActive = false,
    this.airgapTurns = 0,
    this.amplifyNext = false,
    this.costReduceNext = false,
    this.skipNextDraw = false,
    this.mitmActive = false,
    this.trojanTurns = 0,
    this.wafActive = false,
  })  : deck = deck ?? [],
        hand = hand ?? [],
        graveyard = graveyard ?? [];
}

// ===== ステージデータ =====
class StageData {
  final int stageId;
  final String name;
  final String enemyName;
  final int enemyHp;
  final int enemyMaxMana;
  final String description;
  final int difficulty;
  final List<String> enemyDeckIds;
  final int rewardXp;
  final String? unlockCardId;

  const StageData({
    required this.stageId,
    required this.name,
    required this.enemyName,
    required this.enemyHp,
    required this.enemyMaxMana,
    required this.description,
    required this.difficulty,
    required this.enemyDeckIds,
    required this.rewardXp,
    this.unlockCardId,
  });
}

class StageDatabase {
  static const List<StageData> stages = [
    StageData(
      stageId: 1, name: 'Script Kiddie', enemyName: 'スクリプトキディ',
      enemyHp: 25, enemyMaxMana: 6, difficulty: 1,
      description: '基本スクリプトしか使えない初心者。',
      enemyDeckIds: [
        'atk_001','atk_001','atk_002','atk_013','atk_013',
        'def_001','def_001','def_002','spc_002','spc_002',
        'atk_006','def_009','spc_004','atk_003','def_010',
        'spc_003','atk_002','def_002','atk_001','spc_007',
      ],
      rewardXp: 100, unlockCardId: 'atk_009',
    ),
    StageData(
      stageId: 2, name: 'Phisher', enemyName: 'フィッシャー',
      enemyHp: 28, enemyMaxMana: 7, difficulty: 1,
      description: 'フィッシング攻撃を得意とするハッカー。',
      enemyDeckIds: [
        'atk_003','atk_003','atk_010','atk_010','atk_001',
        'spc_001','spc_002','spc_002','spc_006','def_001',
        'def_001','def_002','atk_006','def_009','def_010',
        'spc_004','atk_013','def_003','spc_003','atk_002',
      ],
      rewardXp: 150, unlockCardId: 'atk_010',
    ),
    StageData(
      stageId: 3, name: 'Cracker', enemyName: 'クラッカー',
      enemyHp: 30, enemyMaxMana: 7, difficulty: 2,
      description: 'パスワードクラックを専門とする。',
      enemyDeckIds: [
        'atk_006','atk_006','atk_009','atk_009','atk_002',
        'spc_002','spc_003','spc_004','def_001','def_003',
        'def_003','def_007','atk_003','atk_010','spc_007',
        'exp_002','exp_002','def_010','atk_013','spc_006',
      ],
      rewardXp: 200, unlockCardId: 'exp_002',
    ),
    StageData(
      stageId: 4, name: 'Black Hat', enemyName: 'ブラックハット',
      enemyHp: 32, enemyMaxMana: 8, difficulty: 2,
      description: 'マルウェアと毒攻撃を使いこなす。',
      enemyDeckIds: [
        'atk_007','atk_007','atk_008','atk_008','atk_003',
        'exp_002','exp_002','spc_001','spc_004','spc_007',
        'def_003','def_003','def_007','def_009','atk_009',
        'atk_002','spc_003','def_005','atk_010','exp_001',
      ],
      rewardXp: 250, unlockCardId: 'atk_011',
    ),
    StageData(
      stageId: 5, name: 'Exploit Dev', enemyName: 'エクスプロイト開発者',
      enemyHp: 35, enemyMaxMana: 8, difficulty: 3,
      description: 'バッファオーバーフローとバグ攻撃の専門家。',
      enemyDeckIds: [
        'atk_008','atk_008','exp_001','exp_001','atk_011',
        'atk_011','atk_004','spc_004','spc_008','spc_009',
        'def_004','def_004','def_005','def_007','def_012',
        'exp_003','exp_002','atk_009','spc_002','atk_012',
      ],
      rewardXp: 350, unlockCardId: 'atk_012',
    ),
    StageData(
      stageId: 6, name: 'APT Hacker', enemyName: 'APTハッカー',
      enemyHp: 38, enemyMaxMana: 9, difficulty: 3,
      description: '国家支援の高度持続的脅威ハッカー。',
      enemyDeckIds: [
        'atk_004','atk_012','atk_014','atk_014','exp_003',
        'exp_005','spc_001','spc_006','spc_009','spc_010',
        'def_005','def_006','def_008','def_011','def_012',
        'atk_008','exp_001','spc_008','atk_011','def_004',
      ],
      rewardXp: 500, unlockCardId: 'atk_014',
    ),
    StageData(
      stageId: 7, name: 'Cyber Criminal', enemyName: 'サイバー犯罪者',
      enemyHp: 40, enemyMaxMana: 9, difficulty: 4,
      description: 'ランサムウェアとルートキットを操る。',
      enemyDeckIds: [
        'atk_004','atk_004','atk_015','exp_001','exp_003',
        'exp_005','exp_006','spc_005','spc_006','spc_008',
        'def_006','def_008','def_011','def_012','atk_014',
        'atk_012','exp_002','spc_009','spc_010','atk_008',
      ],
      rewardXp: 700, unlockCardId: 'exp_005',
    ),
    StageData(
      stageId: 8, name: 'Shadow Broker', enemyName: 'シャドウブローカー',
      enemyHp: 50, enemyMaxMana: 10, difficulty: 5,
      description: '最強のブラックハッカー。ゼロデイとカーネルパニック使用。',
      enemyDeckIds: [
        'atk_005','atk_005','exp_004','exp_007','exp_006',
        'atk_016','atk_015','spc_005','spc_005','spc_007',
        'def_006','def_008','def_011','def_012','exp_005',
        'atk_004','exp_003','spc_008','spc_009','def_004',
      ],
      rewardXp: 1000, unlockCardId: 'atk_005',
    ),
    StageData(
      stageId: 9, name: 'Shadow Broker+', enemyName: 'シャドウブローカーEX',
      enemyHp: 60, enemyMaxMana: 10, difficulty: 5,
      description: 'NG+。さらに強化されたラスボス。全カード使用。',
      enemyDeckIds: [
        'atk_005','atk_005','exp_004','exp_004','exp_007',
        'exp_007','atk_016','atk_015','atk_015','spc_005',
        'spc_005','def_008','def_011','def_012','exp_006',
        'exp_006','atk_004','exp_005','spc_008','def_006',
      ],
      rewardXp: 2000,
    ),
  ];

  static StageData? getById(int id) {
    try { return stages.firstWhere((s) => s.stageId == id); } catch (_) { return null; }
  }
}

// ===== 実績 =====
class Achievement {
  final String id;
  final String title;
  final String description;
  final String icon;
  final int xpReward;

  const Achievement({
    required this.id, required this.title,
    required this.description, required this.icon, required this.xpReward,
  });
}

class AchievementDatabase {
  static const List<Achievement> all = [
    Achievement(id: 'first_win',    title: '初勝利',       description: '最初の戦いに勝利した',         icon: '🏆', xpReward: 50),
    Achievement(id: 'stage_3',      title: 'ワールド1制覇', description: 'ステージ3をクリア',             icon: '🌐', xpReward: 100),
    Achievement(id: 'stage_5',      title: 'ワールド2制覇', description: 'ステージ5をクリア',             icon: '💻', xpReward: 200),
    Achievement(id: 'stage_8',      title: 'ラスボス討伐',  description: 'シャドウブローカーを倒した',   icon: '👑', xpReward: 500),
    Achievement(id: 'stage_9',      title: 'NG+制覇',      description: '二周目ボスを倒した',             icon: '🔥', xpReward: 1000),
    Achievement(id: 'win_10',       title: '10勝達成',      description: '10回の対戦で勝利',              icon: '⚡', xpReward: 300),
    Achievement(id: 'no_damage',    title: 'ノーダメージ',  description: '一度もダメージなしで勝利',      icon: '🛡️', xpReward: 250),
    Achievement(id: 'all_cards',    title: 'カードコンプ',  description: '全カードをアンロック',           icon: '🃏', xpReward: 500),
    Achievement(id: 'hard_win',     title: 'ハードクリア',  description: 'Hard難易度でクリア',             icon: '💀', xpReward: 400),
    Achievement(id: 'online_win',   title: 'オンライン勝利', description: 'オンライン対戦で勝利',         icon: '🌍', xpReward: 200),
    Achievement(id: 'wifi_win',     title: 'WiFi対戦勝利',  description: 'WiFiローカル対戦で勝利',        icon: '📶', xpReward: 200),
    Achievement(id: 'legendary_play',title: 'レジェンダリー', description: 'Legendaryカードをプレイ',    icon: '✨', xpReward: 100),
    Achievement(id: 'black_role',   title: 'ブラックハット', description: 'ブラックハッカーとしてプレイ', icon: '🖤', xpReward: 150),
    Achievement(id: 'full_deck',    title: 'フルデッキ',    description: 'デッキ20枚すべて異なるカード', icon: '🎴', xpReward: 200),
  ];
}
