import 'package:flutter/material.dart';

class HudWidget extends StatelessWidget {
  final String name;
  final int hp;
  final int maxHp;
  final int shield;
  final int mana;
  final int maxMana;
  final bool isEnemy;
  final int poisonTurns;

  const HudWidget({
    super.key,
    required this.name,
    required this.hp,
    required this.maxHp,
    required this.shield,
    required this.mana,
    required this.maxMana,
    required this.isEnemy,
    this.poisonTurns = 0,
  });

  @override
  Widget build(BuildContext context) {
    final hpPct = maxHp > 0 ? hp / maxHp : 0.0;
    final hpColor = hpPct > 0.5
        ? const Color(0xFF00FF88)
        : hpPct > 0.25
            ? const Color(0xFFFFAA00)
            : const Color(0xFFFF4444);

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: isEnemy
            ? const Color(0xFF1A0A0A)
            : const Color(0xFF0A1A0A),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: isEnemy
              ? const Color(0xFF3A1A1A)
              : const Color(0xFF1A3A1A),
        ),
      ),
      child: Row(
        children: [
          // アバター
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isEnemy
                  ? const Color(0xFF2A0A0A)
                  : const Color(0xFF0A2A0A),
              border: Border.all(
                color: isEnemy
                    ? const Color(0xFFFF4444).withValues(alpha: 0.5)
                    : const Color(0xFF00FF88).withValues(alpha: 0.5),
              ),
            ),
            child: Center(
              child: Text(
                isEnemy ? '💀' : '👨‍💻',
                style: const TextStyle(fontSize: 18),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        name,
                        style: TextStyle(
                          color: isEnemy
                              ? const Color(0xFFFF8888)
                              : const Color(0xFF88FF88),
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.5,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (poisonTurns > 0)
                      Container(
                        margin: const EdgeInsets.only(left: 4),
                        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                        decoration: BoxDecoration(
                          color: const Color(0xFF441A55),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          '☠️×$poisonTurns',
                          style: const TextStyle(fontSize: 9, color: Color(0xFFAA44FF)),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 3),
                // HPバー
                Row(
                  children: [
                    const Text(
                      'HP',
                      style: TextStyle(color: Color(0xFF666666), fontSize: 9),
                    ),
                    const SizedBox(width: 4),
                    Expanded(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(4),
                        child: LinearProgressIndicator(
                          value: hpPct.clamp(0.0, 1.0),
                          backgroundColor: const Color(0xFF1A1A1A),
                          color: hpColor,
                          minHeight: 8,
                        ),
                      ),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      '$hp/$maxHp',
                      style: TextStyle(
                        color: hpColor,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          // シールド表示
          Column(
            children: [
              if (shield > 0) ...[
                Text(
                  '🛡️',
                  style: const TextStyle(fontSize: 14),
                ),
                Text(
                  '$shield',
                  style: const TextStyle(
                    color: Color(0xFF44AAFF),
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ] else ...[
                const Text('🛡️', style: TextStyle(fontSize: 14, color: Color(0xFF222244))),
                const Text(
                  '0',
                  style: TextStyle(color: Color(0xFF333355), fontSize: 12),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}
