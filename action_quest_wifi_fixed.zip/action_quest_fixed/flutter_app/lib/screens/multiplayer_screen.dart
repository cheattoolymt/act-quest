import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:permission_handler/permission_handler.dart';
import '../providers/game_provider.dart';
import '../services/network_service.dart';
import 'pvp_battle_screen.dart';

enum MultiplayerMode { online, wifi }

class MultiplayerScreen extends StatefulWidget {
  final MultiplayerMode mode;
  const MultiplayerScreen({super.key, required this.mode});

  @override
  State<MultiplayerScreen> createState() => _MultiplayerScreenState();
}

class _MultiplayerScreenState extends State<MultiplayerScreen> {
  final _wifiService = WifiP2pService();
  final _onlineService = OnlineP2pService();
  final _ipCtrl = TextEditingController();
  bool _isHost = false;
  bool _connecting = false;
  bool _navigated = false;
  String _detectedIp = '';

  @override
  void initState() {
    super.initState();
    // 接続成功コールバック（500ms待ってからpvp画面へ）
    // BUG-FIX: ホスト・ゲスト両方で遷移するよう修正（_isHostの条件を削除）
    _wifiService.onConnected = () {
      if (mounted && !_navigated) {
        Future.delayed(const Duration(milliseconds: 500), () {
          if (mounted && !_navigated) _doNavigate(isHost: _isHost, mode: 'wifi');
        });
      }
    };
    _onlineService.onOpponentConnected = () {
      if (mounted && !_navigated) _doNavigate(isHost: _isHost, mode: 'online');
    };
    // Android 8〜16: WiFi IP取得のためロケーション権限をリクエスト後にIPをプリロード
    _requestPermissionsAndPreloadIp();
  }

  /// Android 8〜16対応: ロケーション権限をリクエストしてからIPを取得
  Future<void> _requestPermissionsAndPreloadIp() async {
    if (Platform.isAndroid) {
      // Android 13+(API33+): NEARBY_WIFI_DEVICES が優先
      // Android 8〜12: ACCESS_FINE_LOCATION が必要
      // permission_handler が内部でSDKバージョンを判断するため両方リクエストしてOK
      await [
        Permission.locationWhenInUse,
        Permission.nearbyWifiDevices,
      ].request();
    }
    await _preloadIp();
  }

  Future<void> _preloadIp() async {
    try {
      final interfaces = await NetworkInterface.list(
        type: InternetAddressType.IPv4,
        includeLinkLocal: false,
      );
      for (final iface in interfaces) {
        for (final addr in iface.addresses) {
          if (!addr.isLoopback) {
            if (addr.address.startsWith('192.168.') ||
                addr.address.startsWith('10.')) {
              if (mounted) setState(() => _detectedIp = addr.address);
              return;
            }
          }
        }
      }
      // 192/10以外でも表示
      for (final iface in interfaces) {
        for (final addr in iface.addresses) {
          if (!addr.isLoopback && addr.address != '0.0.0.0') {
            if (mounted) setState(() => _detectedIp = addr.address);
            return;
          }
        }
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    _wifiService.dispose();
    _onlineService.dispose();
    _ipCtrl.dispose();
    super.dispose();
  }

  Color get _modeColor => widget.mode == MultiplayerMode.online
      ? const Color(0xFF00AAFF)
      : const Color(0xFF8866FF);

  void _doNavigate({required bool isHost, required String mode}) {
    if (_navigated) return;
    _navigated = true;
    final gp = context.read<GameProvider>();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => PvpBattleScreen(
          playerName: gp.playerName,
          playerRole: gp.playerRole,
          playerDeckIds: gp.deckCardIds,
          isHost: isHost,
          mode: mode,
          wifiService: mode == 'wifi' ? _wifiService : null,
          onlineService: mode == 'online' ? _onlineService : null,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A1A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0F1A2E),
        title: Text(
          widget.mode == MultiplayerMode.online ? 'ONLINE BATTLE' : 'WiFi LOCAL BATTLE',
          style: TextStyle(
              color: _modeColor, letterSpacing: 2,
              fontWeight: FontWeight.bold, fontSize: 15),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: _modeColor),
          onPressed: () {
            _wifiService.disconnect();
            _onlineService.disconnect();
            Navigator.pop(context);
          },
        ),
      ),
      body: widget.mode == MultiplayerMode.online
          ? _buildOnlineUI()
          : _buildWifiUI(),
    );
  }

  // ===== WiFiローカル =====
  Widget _buildWifiUI() {
    return ListenableBuilder(
      listenable: _wifiService,
      builder: (_, __) {
        final isConnected = _wifiService.isConnected;
        final state = _wifiService.state;
        return SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 8),
              // デバイスIP表示カード
              if (_detectedIp.isNotEmpty)
                _IpInfoCard(ip: _detectedIp, color: const Color(0xFF8866FF)),
              const SizedBox(height: 12),
              _StatusCard(
                message: _wifiService.statusMessage,
                color: const Color(0xFF8866FF),
                isConnected: isConnected,
              ),
              const SizedBox(height: 20),
              // ホスト
              _ActionCard(
                icon: '📡',
                title: 'ホスト（待ち受け）',
                subtitle: '同じWiFiで相手を待つ',
                color: const Color(0xFF8866FF),
                isLoading: _connecting && _isHost && state == WifiP2pState.hosting,
                enabled: !isConnected && !_connecting,
                onTap: () async {
                  setState(() { _isHost = true; _connecting = true; _navigated = false; });
                  await _wifiService.startHost();
                  if (mounted) setState(() => _connecting = false);
                },
              ),
              const SizedBox(height: 14),
              // ゲスト
              _ActionCard(
                icon: '🔗',
                title: 'ゲスト（接続する）',
                subtitle: 'ホストのIPアドレスを入力',
                color: const Color(0xFF6644AA),
                isLoading: _connecting && !_isHost,
                enabled: !isConnected && !_connecting,
                onTap: () => _showIpDialog(isOnline: false),
              ),
              // 接続済み→バトル開始ボタン（ゲスト側）
              if (isConnected && !_isHost) ...[
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    icon: const Text('⚔️'),
                    label: const Text('バトル開始！',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF8866FF),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                    onPressed: () => _doNavigate(isHost: false, mode: 'wifi'),
                  ),
                ),
              ],
              // エラー時のリセットボタン
              if (state == WifiP2pState.error) ...[
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.refresh, size: 16),
                    label: const Text('リセットして再試行'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFF8866FF),
                      side: const BorderSide(color: Color(0xFF8866FF)),
                    ),
                    onPressed: () {
                      _wifiService.disconnect();
                      setState(() { _connecting = false; _navigated = false; });
                    },
                  ),
                ),
              ],
              const SizedBox(height: 24),
              _HowToCard(
                color: const Color(0xFF8866FF),
                lines: const [
                  '① 2台とも同じWiFiに接続する',
                  '② ホストが「ホスト」を押してIPを確認',
                  '③ ゲストが表示されたIPを入力して接続',
                  '④ 接続後「バトル開始」を押す',
                  '✅ サーバー不要・完全ローカル通信',
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  // ===== オンライン =====
  Widget _buildOnlineUI() {
    return ListenableBuilder(
      listenable: _onlineService,
      builder: (_, __) {
        final isConnected = _onlineService.isConnected;
        final state = _onlineService.state;
        return SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 8),
              if (_detectedIp.isNotEmpty)
                _IpInfoCard(ip: _detectedIp, color: const Color(0xFF00AAFF)),
              const SizedBox(height: 12),
              _StatusCard(
                message: _onlineService.statusMessage,
                color: const Color(0xFF00AAFF),
                isConnected: isConnected,
              ),
              const SizedBox(height: 20),
              // ホスト
              _ActionCard(
                icon: '📡',
                title: 'ホスト（待ち受け）',
                subtitle: '相手にIPアドレスを教える',
                color: const Color(0xFF00AAFF),
                isLoading: _connecting && _isHost && state == OnlineState.hosting,
                enabled: !isConnected && !_connecting,
                onTap: () async {
                  setState(() { _isHost = true; _connecting = true; _navigated = false; });
                  await _onlineService.createRoom();
                  if (mounted) setState(() => _connecting = false);
                },
              ),
              const SizedBox(height: 14),
              // ゲスト
              _ActionCard(
                icon: '🔗',
                title: 'ゲスト（接続する）',
                subtitle: 'ホストのIPアドレスを入力',
                color: const Color(0xFF44AAFF),
                isLoading: _connecting && !_isHost,
                enabled: !isConnected && !_connecting,
                onTap: () => _showIpDialog(isOnline: true),
              ),
              // ゲスト接続済み→バトル開始
              if (isConnected && !_isHost) ...[
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    icon: const Text('⚔️'),
                    label: const Text('バトル開始！',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF00AAFF),
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                    onPressed: () => _doNavigate(isHost: false, mode: 'online'),
                  ),
                ),
              ],
              // エラー時のリセットボタン
              if (state == OnlineState.error) ...[
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.refresh, size: 16),
                    label: const Text('リセットして再試行'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFF00AAFF),
                      side: const BorderSide(color: Color(0xFF00AAFF)),
                    ),
                    onPressed: () {
                      _onlineService.disconnect();
                      setState(() { _connecting = false; _navigated = false; });
                    },
                  ),
                ),
              ],
              const SizedBox(height: 24),
              _HowToCard(
                color: const Color(0xFF00AAFF),
                lines: const [
                  '① ホストが「ホスト」を押してIPを確認',
                  '② そのIPを相手に伝える（チャット・口頭）',
                  '③ ゲストがIPアドレスを入力して「接続」',
                  '④ 両者「バトル開始」を押してスタート',
                  '⚠️ 同じネットワーク or ポート開放が必要',
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  void _showIpDialog({required bool isOnline}) {
    _ipCtrl.clear();
    // 前回入力や検出IPをプリセット
    if (_detectedIp.isNotEmpty) {
      final parts = _detectedIp.split('.');
      if (parts.length == 4) {
        // サブネットのみプリセット（ホストのIPは不明なのでそのまま）
      }
    }
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF0F1A2E),
        title: Text(
          'ホストのIPアドレス',
          style: TextStyle(color: _modeColor, fontSize: 16),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _ipCtrl,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              style: const TextStyle(
                  color: Colors.white, fontSize: 18, letterSpacing: 1.5),
              decoration: InputDecoration(
                hintText: '192.168.x.x',
                hintStyle: const TextStyle(color: Color(0xFF333355)),
                prefixIcon: Icon(Icons.wifi, color: _modeColor),
                enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: _modeColor.withValues(alpha: 0.3))),
                focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: _modeColor)),
              ),
              autofocus: true,
            ),
            const SizedBox(height: 10),
            if (_detectedIp.isNotEmpty)
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFF0A0A18),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: const Color(0xFF1A3A5C)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.info_outline, size: 12, color: Color(0xFF444466)),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        'あなたのIP: $_detectedIp',
                        style: const TextStyle(color: Color(0xFF555577), fontSize: 10),
                      ),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 8),
            const Text(
              'ホスト側の画面に表示されたIPを入力\n（例: 192.168.1.100）',
              style: TextStyle(color: Color(0xFF666688), fontSize: 11),
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('キャンセル',
                style: TextStyle(color: Color(0xFF666666))),
          ),
          ElevatedButton(
            onPressed: () async {
              final ip = _ipCtrl.text.trim();
              if (ip.isEmpty) return;
              Navigator.pop(context);
              setState(() {
                _isHost = false;
                _connecting = true;
                _navigated = false;
              });

              bool ok;
              if (isOnline) {
                ok = await _onlineService.joinRoom(ip);
                // BUG-FIX: 遷移は onOpponentConnected コールバックに統一
                // (okでの二重遷移を防ぐためここでは _doNavigate を呼ばない)
                if (!ok && mounted) {
                  // 接続失敗時のみUI更新
                }
              } else {
                ok = await _wifiService.connectToHost(ip);
                // BUG-FIX: 遷移は onConnected コールバックに統一
                if (!ok && mounted) {
                  // 接続失敗時のみUI更新
                }
              }
              if (mounted) setState(() => _connecting = false);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: _modeColor,
              foregroundColor: Colors.black,
            ),
            child: const Text('接続', style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }
}

// ===== ウィジェット群 =====

/// デバイスIP表示カード（ホスト用）
class _IpInfoCard extends StatelessWidget {
  final String ip;
  final Color color;
  const _IpInfoCard({required this.ip, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.07),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Row(
        children: [
          Icon(Icons.smartphone, color: color.withValues(alpha: 0.7), size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'このデバイスのIP',
                  style: TextStyle(color: color.withValues(alpha: 0.6), fontSize: 10),
                ),
                Text(
                  ip,
                  style: TextStyle(
                    color: color,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'monospace',
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            icon: Icon(Icons.copy, size: 16, color: color.withValues(alpha: 0.6)),
            tooltip: 'IPをコピー',
            onPressed: () {
              Clipboard.setData(ClipboardData(text: ip));
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('IPをコピーしました: $ip'),
                  duration: const Duration(seconds: 2),
                  backgroundColor: const Color(0xFF00FF88),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _StatusCard extends StatelessWidget {
  final String message;
  final Color color;
  final bool isConnected;
  const _StatusCard(
      {required this.message, required this.color, required this.isConnected});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isConnected
            ? color.withValues(alpha: 0.1)
            : const Color(0xFF0A0A18),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
            color: isConnected ? color.withValues(alpha: 0.6) : const Color(0xFF1A1A3A)),
      ),
      child: Row(
        children: [
          Icon(
            isConnected ? Icons.check_circle : Icons.info_outline,
            color: isConnected ? color : const Color(0xFF444466),
            size: 18,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              message,
              style: TextStyle(
                color: isConnected ? color : const Color(0xFF666688),
                fontSize: 12,
                fontFamily: 'monospace',
                height: 1.5,
              ),
            ),
          ),
          // IPのクリップボードコピー（ステータスメッセージにIPが含まれる場合）
          if (message.contains('IP:') || message.contains('IP\n') || message.contains('あなたのIP'))
            IconButton(
              icon: const Icon(Icons.copy, size: 16, color: Color(0xFF444466)),
              tooltip: 'IPをコピー',
              onPressed: () {
                final match =
                    RegExp(r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})').firstMatch(message);
                if (match != null) {
                  Clipboard.setData(ClipboardData(text: match.group(0)!));
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('IPをコピーしました: ${match.group(0)}'),
                      duration: const Duration(seconds: 2),
                      backgroundColor: const Color(0xFF00FF88),
                    ),
                  );
                }
              },
            ),
        ],
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  final String icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback? onTap;
  final bool isLoading;
  final bool enabled;

  const _ActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    this.onTap,
    this.isLoading = false,
    this.enabled = true,
  });

  @override
  Widget build(BuildContext context) {
    final active = enabled && !isLoading;
    return GestureDetector(
      onTap: active ? onTap : null,
      child: AnimatedOpacity(
        opacity: active ? 1.0 : 0.5,
        duration: const Duration(milliseconds: 200),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFF0F1A2E),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
                color: active ? color.withValues(alpha: 0.5) : const Color(0xFF1A1A3A)),
            boxShadow: active
                ? [BoxShadow(color: color.withValues(alpha: 0.08), blurRadius: 8)]
                : [],
          ),
          child: Row(
            children: [
              Text(icon, style: const TextStyle(fontSize: 28)),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: TextStyle(
                            color: active ? color : const Color(0xFF666688),
                            fontSize: 14,
                            fontWeight: FontWeight.bold)),
                    const SizedBox(height: 2),
                    Text(subtitle,
                        style: const TextStyle(
                            color: Color(0xFF555577), fontSize: 11)),
                  ],
                ),
              ),
              if (isLoading)
                SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                        color: color, strokeWidth: 2.5))
              else
                Icon(Icons.arrow_forward_ios,
                    color: color.withValues(alpha: active ? 0.6 : 0.2), size: 16),
            ],
          ),
        ),
      ),
    );
  }
}

class _HowToCard extends StatelessWidget {
  final Color color;
  final List<String> lines;
  const _HowToCard({required this.color, required this.lines});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0A0A18),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFF1A2A3A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('ℹ️ 接続手順',
              style: TextStyle(
                  color: color, fontSize: 12, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ...lines.map((l) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 2),
                child: Text(l,
                    style: const TextStyle(
                        color: Color(0xFF666688), fontSize: 11, height: 1.4)),
              )),
        ],
      ),
    );
  }
}
