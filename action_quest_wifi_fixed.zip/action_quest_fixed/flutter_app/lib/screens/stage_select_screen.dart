import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/game_models.dart';
import '../providers/game_provider.dart';
import 'battle_screen.dart';

class StageSelectScreen extends StatelessWidget {
  const StageSelectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<GameProvider>(
      builder: (context, gp, _) {
        return Scaffold(
          backgroundColor: const Color(0xFF0A0A1A),
          appBar: AppBar(
            backgroundColor: const Color(0xFF0F1A2E),
            title: const Text(
              'STAGE SELECT',
              style: TextStyle(
                color: Color(0xFF00FF88),
                letterSpacing: 2,
                fontWeight: FontWeight.bold,
              ),
            ),
            leading: IconButton(
              icon: const Icon(Icons.arrow_back, color: Color(0xFF00FF88)),
              onPressed: () => Navigator.pop(context),
            ),
          ),
          body: Column(
            children: [
              // 難易度選択バー
              _DifficultyBar(),
              // ステージリスト
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: StageDatabase.stages.length,
                  itemBuilder: (context, index) {
                    final stage = StageDatabase.stages[index];
                    final cleared = gp.clearedStages.contains(stage.stageId);
                    // NG+はステージ8クリアが必要
                    final locked = stage.stageId == 9 && !gp.ngPlusUnlocked;
                    // 通常のロック（前のステージをクリアしてないと開放されない）
                    final prevLocked = stage.stageId > 1 &&
                        !gp.clearedStages.contains(stage.stageId - 1) &&
                        !cleared;

                    return _StageCard(
                      stage: stage,
                      cleared: cleared,
                      locked: locked || prevLocked,
                      gp: gp,
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

// 難易度選択（グローバルステート使わずStatefulWidget）
class _DifficultyBar extends StatefulWidget {
  @override
  State<_DifficultyBar> createState() => _DifficultyBarState();
}

class _DifficultyBarState extends State<_DifficultyBar> {
  int _selected = 1; // 0=Easy, 1=Normal, 2=Hard

  static const labels = ['EASY', 'NORMAL', 'HARD'];
  static const colors = [Color(0xFF44FF88), Color(0xFFFFAA00), Color(0xFFFF4444)];

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      color: const Color(0xFF0F1A2E),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '難易度選択',
            style: TextStyle(color: Color(0xFF666666), fontSize: 11),
          ),
          const SizedBox(height: 8),
          Row(
            children: List.generate(3, (i) {
              return Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => _selected = i),
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      color: _selected == i
                          ? colors[i].withValues(alpha: 0.2)
                          : const Color(0xFF0A0A1A),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: _selected == i ? colors[i] : const Color(0xFF1A3A5C),
                        width: _selected == i ? 2 : 1,
                      ),
                    ),
                    child: Text(
                      labels[i],
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: _selected == i ? colors[i] : const Color(0xFF666666),
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }

  int get selectedDifficulty => _selected;
}

class _StageCard extends StatelessWidget {
  final StageData stage;
  final bool cleared;
  final bool locked;
  final GameProvider gp;

  const _StageCard({
    required this.stage,
    required this.cleared,
    required this.locked,
    required this.gp,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: locked
          ? null
          : () {
              // 難易度取得（親の_DifficultyBarStateから直接は取れないため、デフォルトNormalで）
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => BattleScreen(
                    stage: stage,
                    difficulty: 1, // Normal default (実際は難易度バーから取得)
                    playerName: gp.playerName,
                    playerDeckIds: gp.deckCardIds,
                  ),
                ),
              );
            },
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: locked
              ? const Color(0xFF080812)
              : cleared
                  ? const Color(0xFF0A1A0A)
                  : const Color(0xFF0F1A2E),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: locked
                ? const Color(0xFF1A1A2E)
                : cleared
                    ? const Color(0xFF00FF88).withValues(alpha: 0.4)
                    : const Color(0xFF1A3A5C),
          ),
        ),
        child: Row(
          children: [
            // ステージ番号
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: locked
                    ? const Color(0xFF1A1A2E)
                    : cleared
                        ? const Color(0xFF00FF88).withValues(alpha: 0.2)
                        : const Color(0xFF1A3A5C),
                border: Border.all(
                  color: locked
                      ? const Color(0xFF2A2A4E)
                      : cleared
                          ? const Color(0xFF00FF88)
                          : const Color(0xFF1A5C8A),
                ),
              ),
              child: Center(
                child: locked
                    ? const Icon(Icons.lock, color: Color(0xFF444466), size: 20)
                    : cleared
                        ? const Text('✓', style: TextStyle(color: Color(0xFF00FF88), fontSize: 20, fontWeight: FontWeight.bold))
                        : Text(
                            '${stage.stageId}',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        stage.name,
                        style: TextStyle(
                          color: locked ? const Color(0xFF444466) : Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(width: 8),
                      if (!locked)
                        _DiffDots(stage.difficulty),
                    ],
                  ),
                  Text(
                    locked ? '前のステージをクリアして解放' : stage.description,
                    style: TextStyle(
                      color: locked ? const Color(0xFF333355) : const Color(0xFF666688),
                      fontSize: 11,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (!locked) ...[
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Text(
                          'HP: ${stage.enemyHp}',
                          style: const TextStyle(color: Color(0xFFFF4444), fontSize: 10),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'XP: +${stage.rewardXp}',
                          style: const TextStyle(color: Color(0xFFFFAA00), fontSize: 10),
                        ),
                        if (stage.unlockCardId != null) ...[
                          const SizedBox(width: 8),
                          const Text(
                            '🃏 新カード',
                            style: TextStyle(color: Color(0xFF8866FF), fontSize: 10),
                          ),
                        ],
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DiffDots extends StatelessWidget {
  final int difficulty;
  const _DiffDots(this.difficulty);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: List.generate(5, (i) {
        return Container(
          width: 6,
          height: 6,
          margin: const EdgeInsets.only(right: 2),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: i < difficulty
                ? (difficulty >= 4
                    ? const Color(0xFFFF4444)
                    : difficulty >= 3
                        ? const Color(0xFFFFAA00)
                        : const Color(0xFF44FF88))
                : const Color(0xFF1A3A5C),
          ),
        );
      }),
    );
  }
}
