import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/game_models.dart';
import '../providers/game_provider.dart';

class AchievementScreen extends StatelessWidget {
  const AchievementScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<GameProvider>(
      builder: (context, gp, _) {
        final earned = gp.earnedAchievementIds.toSet();
        return Scaffold(
          backgroundColor: const Color(0xFF0A0A1A),
          appBar: AppBar(
            backgroundColor: const Color(0xFF0F1A2E),
            title: Text(
              'ACHIEVEMENTS ${earned.length}/${AchievementDatabase.all.length}',
              style: const TextStyle(
                color: Color(0xFFFF8844),
                letterSpacing: 1.5,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
            leading: IconButton(
              icon: const Icon(Icons.arrow_back, color: Color(0xFFFF8844)),
              onPressed: () => Navigator.pop(context),
            ),
          ),
          body: Column(
            children: [
              // 進捗バー
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                color: const Color(0xFF0F1A2E),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          '達成率',
                          style: TextStyle(color: Color(0xFF888899), fontSize: 12),
                        ),
                        Text(
                          '${earned.length}/${AchievementDatabase.all.length}  (${(earned.length / AchievementDatabase.all.length * 100).round()}%)',
                          style: const TextStyle(
                            color: Color(0xFFFF8844),
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: earned.length / AchievementDatabase.all.length,
                        backgroundColor: const Color(0xFF1A3A5C),
                        color: const Color(0xFFFF8844),
                        minHeight: 6,
                      ),
                    ),
                  ],
                ),
              ),
              // 実績リスト
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(10),
                  itemCount: AchievementDatabase.all.length,
                  itemBuilder: (context, index) {
                    final ach = AchievementDatabase.all[index];
                    final isEarned = earned.contains(ach.id);
                    return Container(
                      margin: const EdgeInsets.only(bottom: 6),
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                      decoration: BoxDecoration(
                        color: isEarned
                            ? const Color(0xFF1A1A0A)
                            : const Color(0xFF0A0A12),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: isEarned
                              ? const Color(0xFFFF8844).withValues(alpha: 0.5)
                              : const Color(0xFF1A1A2E),
                        ),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          // アイコン
                          SizedBox(
                            width: 42,
                            height: 42,
                            child: Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: isEarned
                                    ? const Color(0xFFFF8844).withValues(alpha: 0.2)
                                    : const Color(0xFF1A1A2E),
                              ),
                              child: Center(
                                child: Text(
                                  isEarned ? ach.icon : '🔒',
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: isEarned ? null : const Color(0xFF333355),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          // テキスト
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  isEarned ? ach.title : '???',
                                  style: TextStyle(
                                    color: isEarned
                                        ? Colors.white
                                        : const Color(0xFF444466),
                                    fontSize: 13,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  isEarned ? ach.description : '未達成',
                                  style: TextStyle(
                                    color: isEarned
                                        ? const Color(0xFF888899)
                                        : const Color(0xFF2A2A4A),
                                    fontSize: 10,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 2,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 6),
                          // XP報酬
                          if (isEarned)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 3),
                              decoration: BoxDecoration(
                                color: const Color(0xFFFFAA00).withValues(alpha: 0.2),
                                borderRadius: BorderRadius.circular(6),
                                border: Border.all(
                                  color: const Color(0xFFFFAA00).withValues(alpha: 0.3),
                                ),
                              ),
                              child: Text(
                                '+${ach.xpReward}XP',
                                style: const TextStyle(
                                  color: Color(0xFFFFAA00),
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            )
                          else
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                              decoration: BoxDecoration(
                                color: const Color(0xFF1A1A2E),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                '${ach.xpReward}XP',
                                style: const TextStyle(
                                  color: Color(0xFF333355),
                                  fontSize: 10,
                                ),
                              ),
                            ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
