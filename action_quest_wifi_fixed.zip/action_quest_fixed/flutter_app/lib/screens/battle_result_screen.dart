import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/game_models.dart';
import '../providers/game_provider.dart';
import '../services/battle_service.dart';
import 'main_menu_screen.dart';
import 'stage_select_screen.dart';

class BattleResultScreen extends StatefulWidget {
  final BattleResult result;
  final StageData? stage;
  final int difficulty;
  final bool noPlayerDamage;
  final bool usedLegendary;
  final int playerHp;
  final int enemyHp;
  final int turnNumber;
  final bool isPvp;
  final String pvpMode;

  const BattleResultScreen({
    super.key,
    required this.result,
    required this.stage,
    required this.difficulty,
    required this.noPlayerDamage,
    required this.usedLegendary,
    required this.playerHp,
    required this.enemyHp,
    required this.turnNumber,
    this.isPvp = false,
    this.pvpMode = '',
  });

  @override
  State<BattleResultScreen> createState() => _BattleResultScreenState();
}

class _BattleResultScreenState extends State<BattleResultScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fadeAnim;
  List<String> _newAchievements = [];
  bool _processed = false;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..forward();
    _fadeAnim = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _processResult();
  }

  Future<void> _processResult() async {
    if (_processed) return;
    _processed = true;
    final gp = context.read<GameProvider>();
    if (widget.stage != null) {
      _newAchievements = await gp.reportStageCleared(
        stageId: widget.stage!.stageId,
        won: widget.result == BattleResult.playerWin,
        noPlayerDamage: widget.noPlayerDamage,
        usedLegendary: widget.usedLegendary,
        difficulty: widget.difficulty,
      );
    }
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final won = widget.result == BattleResult.playerWin;
    final primaryColor = won ? const Color(0xFF00FF88) : const Color(0xFFFF4444);
    final icon = won ? '🎉' : '💀';
    final title = won ? 'HACK SUCCESS' : 'SYSTEM BREACH';
    final subtitle = won ? 'ターゲットシステム侵入完了' : 'アクセス拒否';

    return Consumer<GameProvider>(
      builder: (context, gp, _) {
        return Scaffold(
          backgroundColor: const Color(0xFF050510),
          body: SafeArea(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    const SizedBox(height: 24),
                    // 結果アイコン
                    Container(
                      width: 100,
                      height: 100,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: primaryColor.withValues(alpha: 0.1),
                        border: Border.all(color: primaryColor, width: 2),
                        boxShadow: [
                          BoxShadow(
                            color: primaryColor.withValues(alpha: 0.3),
                            blurRadius: 20,
                            spreadRadius: 5,
                          ),
                        ],
                      ),
                      child: Center(
                        child: Text(icon, style: const TextStyle(fontSize: 48)),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      title,
                      style: TextStyle(
                        color: primaryColor,
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 3,
                      ),
                    ),
                    Text(
                      subtitle,
                      style: const TextStyle(color: Color(0xFF666688), fontSize: 13),
                    ),
                    const SizedBox(height: 24),
                    // バトル統計
                    _buildStats(gp),
                    const SizedBox(height: 16),
                    // 新実績
                    if (_newAchievements.isNotEmpty) _buildNewAchievements(),
                    // カードアンロック
                    if (won && widget.stage?.unlockCardId != null)
                      _buildCardUnlock(),
                    const SizedBox(height: 24),
                    // ボタン
                    _buildButtons(context),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildStats(GameProvider gp) {
    final xpGain = widget.result == BattleResult.playerWin
        ? ((widget.stage?.rewardXp ?? 300) *
            (widget.difficulty == 2 ? 1.5 : 1.0)).round()
        : 0;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF0F1A2E),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF1A3A5C)),
      ),
      child: Column(
        children: [
          _StatRow('ターン数', '${widget.turnNumber}', Icons.timer),
          _StatRow('残HP', '${widget.playerHp}', Icons.favorite, color: const Color(0xFFFF6644)),
          _StatRow('敵残HP', '${widget.enemyHp}', Icons.pest_control, color: const Color(0xFFFF4444)),
          if (xpGain > 0)
            _StatRow('獲得XP', '+$xpGain', Icons.star, color: const Color(0xFFFFAA00)),
          _StatRow('通算', '${gp.totalWins}W / ${gp.totalLosses}L', Icons.leaderboard),
        ],
      ),
    );
  }

  Widget _buildNewAchievements() {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A0A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFFFAA00).withValues(alpha: 0.5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '🏆 新実績解除！',
            style: TextStyle(
              color: Color(0xFFFFAA00),
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          ..._newAchievements.map((id) {
            final ach = AchievementDatabase.all
                .where((a) => a.id == id)
                .firstOrNull;
            if (ach == null) return const SizedBox.shrink();
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: Row(
                children: [
                  Text(ach.icon, style: const TextStyle(fontSize: 16)),
                  const SizedBox(width: 8),
                  Text(
                    ach.title,
                    style: const TextStyle(
                        color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    '+${ach.xpReward}XP',
                    style: const TextStyle(color: Color(0xFFFFAA00), fontSize: 11),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildCardUnlock() {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF0A0A1A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF8866FF).withValues(alpha: 0.5)),
      ),
      child: Row(
        children: [
          const Text('🃏', style: TextStyle(fontSize: 24)),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '新カードをアンロック！',
                  style: TextStyle(
                    color: Color(0xFF8866FF),
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  'デッキエディタで確認しよう',
                  style: TextStyle(color: Color(0xFF666688), fontSize: 11),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildButtons(BuildContext context) {
    return Column(
      children: [
        if (widget.stage != null)
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const StageSelectScreen()),
                  (route) => route.isFirst,
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF00FF88),
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: const Text(
                'STAGE SELECT',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, letterSpacing: 2),
              ),
            ),
          ),
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const MainMenuScreen()),
                (route) => false,
              );
            },
            style: OutlinedButton.styleFrom(
              foregroundColor: const Color(0xFF00AAFF),
              side: const BorderSide(color: Color(0xFF00AAFF)),
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
            child: const Text(
              'MAIN MENU',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, letterSpacing: 2),
            ),
          ),
        ),
      ],
    );
  }
}

class _StatRow extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  const _StatRow(this.label, this.value, this.icon,
      {this.color = const Color(0xFF00AAFF)});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, color: color, size: 16),
          const SizedBox(width: 8),
          Text(label, style: const TextStyle(color: Color(0xFF888899), fontSize: 13)),
          const Spacer(),
          Text(
            value,
            style: TextStyle(color: color, fontSize: 13, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
}
