import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/card_model.dart';
import '../models/game_models.dart';
import '../providers/game_provider.dart';
import '../services/battle_service.dart';
import '../services/network_service.dart';
import '../widgets/card_widget.dart';
import '../widgets/hud_widget.dart';
import 'battle_result_screen.dart';

class PvpBattleScreen extends StatefulWidget {
  final String playerName;
  final PlayerRole playerRole;
  final List<String> playerDeckIds;
  final bool isHost;
  final String mode; // 'online' or 'wifi'
  final WifiP2pService? wifiService;
  final OnlineP2pService? onlineService;

  const PvpBattleScreen({
    super.key,
    required this.playerName,
    required this.playerRole,
    required this.playerDeckIds,
    required this.isHost,
    required this.mode,
    this.wifiService,
    this.onlineService,
  });

  @override
  State<PvpBattleScreen> createState() => _PvpBattleScreenState();
}

class _PvpBattleScreenState extends State<PvpBattleScreen> {
  late BattleState _battle;
  bool _waitingForOpponent = true;
  bool _opponentDeckReceived = false;
  bool _battleStarted = false;
  bool _usedLegendary = false;
  // BUG-03修正: _navigateToResult の二重呼び出し防止フラグ
  bool _resultNavigated = false;
  String _opponentName = 'OPPONENT';
  List<String> _opponentDeckIds = [];
  PlayerRole _opponentRole = PlayerRole.black;

  @override
  void initState() {
    super.initState();
    _setupMessageHandlers();
    _initLocalBattle();
    // 1秒後に初回送信、その後3秒おきに届くまで再送し続ける
    Future.delayed(const Duration(seconds: 1), () {
      if (!mounted) return;
      _sendDeckSync();
      _startDeckSyncRetry();
    });
  }

  void _startDeckSyncRetry() {
    Future.delayed(const Duration(seconds: 3), () {
      if (!mounted || _opponentDeckReceived) return;
      _sendDeckSync();
      _startDeckSyncRetry(); // 届くまで繰り返す
    });
  }

  void _setupMessageHandlers() {
    if (widget.wifiService != null) {
      widget.wifiService!.onMessage = _handleP2pMessage;
      widget.wifiService!.onDisconnected = _handleDisconnect;
    }
    if (widget.onlineService != null) {
      widget.onlineService!.onMessage = _handleP2pMessage;
      widget.onlineService!.onOpponentDisconnected = _handleDisconnect;
    }
  }

  void _initLocalBattle() {
    final player = PlayerState(
      id: 'player',
      name: widget.playerName,
      role: widget.playerRole,
      hp: 30, maxHp: 30,
      deck: List.from(widget.playerDeckIds),
    );
    final opponent = PlayerState(
      id: 'opponent',
      name: 'OPPONENT',
      role: widget.playerRole == PlayerRole.white ? PlayerRole.black : PlayerRole.white,
      hp: 30, maxHp: 30,
      deck: List.from(widget.playerDeckIds),
    );
    _battle = BattleState(player: player, enemy: opponent, difficulty: Difficulty.normal);
  }

  void _sendDeckSync() {
    _sendMessage('DECK_SYNC', {
      'name': widget.playerName,
      'deck': widget.playerDeckIds,
      'role': widget.playerRole.index,
    });
  }

  void _handleP2pMessage(WifiP2pMessage msg) {
    if (!mounted) return;
    final data = msg.data;

    switch (msg.type) {
      case 'DECK_SYNC':
        _opponentName = data['name'] as String? ?? 'OPPONENT';
        _opponentDeckIds = List<String>.from(data['deck'] as List? ?? []);
        _opponentRole = PlayerRole.values[data['role'] as int? ?? 1];
        _opponentDeckReceived = true;
        // PlayerStateを再作成して相手情報を更新
        setState(() {
          final newEnemy = PlayerState(
            id: 'opponent',
            name: _opponentName,
            role: _opponentRole,
            hp: _battle.enemy.hp, maxHp: _battle.enemy.maxHp,
            deck: List.from(_opponentDeckIds),
            hand: List.from(_battle.enemy.hand),
            graveyard: List.from(_battle.enemy.graveyard),
          );
          _battle.enemy = newEnemy;
        });
        // ゲスト→ホストへも自分のデッキ送信（相互確認）
        if (!widget.isHost) _sendDeckSync();
        _tryStartBattle();
        break;

      case 'BATTLE_START':
        if (!widget.isHost && !_battleStarted) {
          _battleStarted = true;
          final hostFirst = data['hostFirst'] as bool? ?? true;
          _battle.startBattle();
          // ゲストは後攻
          setState(() {
            _battle.isPlayerTurn = !hostFirst;
            _waitingForOpponent = false;
          });
          _battle.addListener(_onBattleUpdate);
        }
        break;

      case 'PLAY_CARD':
        // 相手がカードを使用→こちらのバトルに反映
        final cardId = data['cardId'] as String? ?? '';
        final stateJson = data['state'] as Map<String, dynamic>?;
        // BUG-05修正: 相手の実際の手札をスナップショットから同期する
        final handList = data['hand'] as List?;
        if (handList != null) {
          setState(() {
            _battle.enemy.hand = List<String>.from(handList);
          });
        }
        // Bug2修正: 送信側で収集したログを受信側で適用する（isPlayerを反転）
        final remoteLogs = data['logs'] as List?;
        if (remoteLogs != null) {
          for (final l in remoteLogs) {
            final msg = l['msg'] as String? ?? '';
            final isP = l['isPlayer'] as bool? ?? false;
            _battle.addLog(msg, isPlayer: !isP);
          }
        }
        _applyOpponentCard(cardId, stateJson);
        break;

      case 'END_TURN':
        // BUG-06修正: END_TURNのstateスナップショットを受信側で適用する
        final endState = data['state'] as Map<String, dynamic>?;
        _handleOpponentEndTurn(endState);
        break;

      case 'SURRENDER':
        if (mounted) {
          setState(() => _battle.result = BattleResult.playerWin);
          _battle.addLog('🏳️ ${_opponentName}が降参しました！', isPlayer: false);
          Future.delayed(const Duration(milliseconds: 600), _navigateToResult);
        }
        break;

      case 'SYNC_STATE':
        // ホストからの完全状態同期
        if (!widget.isHost) {
          _applySyncState(data);
        }
        break;
    }
  }

  void _tryStartBattle() {
    if (widget.isHost && _opponentDeckReceived && !_battleStarted) {
      _battleStarted = true;
      // 相手のデッキを適用してバトル開始
      final newEnemy = PlayerState(
        id: 'opponent',
        name: _opponentName,
        role: _opponentRole,
        hp: 30, maxHp: 30,
        deck: List.from(_opponentDeckIds),
      );
      _battle.enemy = newEnemy;
      _battle.startBattle();
      setState(() => _waitingForOpponent = false);
      _battle.addListener(_onBattleUpdate);
      _sendMessage('BATTLE_START', {'hostFirst': true});
    }
  }

  // 相手カードのローカル反映
  void _applyOpponentCard(String cardId, Map<String, dynamic>? syncState) {
    if (!mounted) return;
    final card = CardDatabase.getById(cardId);
    if (card == null) return;

    setState(() {
      _battle.enemy.hand.remove(cardId);
      _battle.enemy.graveyard.add(cardId);
      // Bug2修正: ログはPLAY_CARDハンドラのlogs同期で追加済みのためここでは追加しない

      // 状態同期データがあれば適用
      if (syncState != null) {
        _applyStateSyncData(syncState);
      }
    });
    _checkBattleEnd();
  }

  void _applySyncState(Map<String, dynamic> data) {
    if (!mounted) return;
    setState(() {
      // プレイヤーHP・シールド・毒等の同期
      final pData = data['player'] as Map<String, dynamic>?;
      final eData = data['enemy'] as Map<String, dynamic>?;
      if (pData != null) {
        _battle.player.hp = pData['hp'] as int? ?? _battle.player.hp;
        _battle.player.shield = pData['shield'] as int? ?? _battle.player.shield;
        _battle.player.poisonTurns = pData['poisonTurns'] as int? ?? _battle.player.poisonTurns;
        _battle.player.mana = pData['mana'] as int? ?? _battle.player.mana;
      }
      if (eData != null) {
        _battle.enemy.hp = eData['hp'] as int? ?? _battle.enemy.hp;
        _battle.enemy.shield = eData['shield'] as int? ?? _battle.enemy.shield;
        _battle.enemy.poisonTurns = eData['poisonTurns'] as int? ?? _battle.enemy.poisonTurns;
        _battle.enemy.mana = eData['mana'] as int? ?? _battle.enemy.mana;
      }
      final turnNum = data['turnNumber'] as int?;
      if (turnNum != null) _battle.turnNumber = turnNum;
    });
  }

  // BUG-02修正: ホスト・ゲスト両方で状態同期を正しく適用する
  void _applyStateSyncData(Map<String, dynamic> state) {
    final playerData = state['player'] as Map<String, dynamic>?;
    final enemyData  = state['enemy']  as Map<String, dynamic>?;

    if (!widget.isHost) {
      // ゲスト側: state.player=送信者(=相手=enemy), state.enemy=受信者(=自分=player)
      if (playerData != null) {
        _battle.enemy.hp          = playerData['hp']          as int? ?? _battle.enemy.hp;
        _battle.enemy.shield      = playerData['shield']      as int? ?? _battle.enemy.shield;
        _battle.enemy.poisonTurns = playerData['poisonTurns'] as int? ?? _battle.enemy.poisonTurns;
      }
      if (enemyData != null) {
        _battle.player.hp          = enemyData['hp']          as int? ?? _battle.player.hp;
        _battle.player.shield      = enemyData['shield']      as int? ?? _battle.player.shield;
        _battle.player.poisonTurns = enemyData['poisonTurns'] as int? ?? _battle.player.poisonTurns;
      }
    } else {
      // ホスト側: state.player=送信者(=相手=enemy), state.enemy=受信者(=自分=player)
      if (playerData != null) {
        _battle.enemy.hp          = playerData['hp']          as int? ?? _battle.enemy.hp;
        _battle.enemy.shield      = playerData['shield']      as int? ?? _battle.enemy.shield;
        _battle.enemy.poisonTurns = playerData['poisonTurns'] as int? ?? _battle.enemy.poisonTurns;
      }
      if (enemyData != null) {
        _battle.player.hp          = enemyData['hp']          as int? ?? _battle.player.hp;
        _battle.player.shield      = enemyData['shield']      as int? ?? _battle.player.shield;
        _battle.player.poisonTurns = enemyData['poisonTurns'] as int? ?? _battle.player.poisonTurns;
      }
    }
  }

  Map<String, dynamic> _buildStateSnapshot() {
    return {
      'player': {
        'hp': _battle.player.hp,
        'shield': _battle.player.shield,
        'poisonTurns': _battle.player.poisonTurns,
        'trojanTurns': _battle.player.trojanTurns,
        'airgapTurns': _battle.player.airgapTurns,
        'regenShieldTurns': _battle.player.regenShieldTurns,
        'mana': _battle.player.mana,
        'manaBoostNext': _battle.player.manaBoostNext,
        'skipNextDraw': _battle.player.skipNextDraw,
        'hand': _battle.player.hand,
      },
      'enemy': {
        'hp': _battle.enemy.hp,
        'shield': _battle.enemy.shield,
        'poisonTurns': _battle.enemy.poisonTurns,
        'trojanTurns': _battle.enemy.trojanTurns,
        'airgapTurns': _battle.enemy.airgapTurns,
        'regenShieldTurns': _battle.enemy.regenShieldTurns,
        'mana': _battle.enemy.mana,
        'manaBoostNext': _battle.enemy.manaBoostNext,
        'skipNextDraw': _battle.enemy.skipNextDraw,
      },
      'turnNumber': _battle.turnNumber,
    };
  }

  // BUG-04修正: ターン開始の状態異常処理をPvPでも実行する
  // BUG-06修正: END_TURNのstateスナップショットを受け取って適用する
  // BUG-08修正: 相手のmanaBoostNextをスナップショット経由で同期する
  // BUG-09修正: skipNextDrawをチェックしてドローをスキップする
  void _handleOpponentEndTurn(Map<String, dynamic>? endState) {
    if (!mounted) return;
    setState(() {
      // BUG-06: END_TURNのstateを適用（マナ・HP・各種フラグを同期）
      if (endState != null) {
        _applyEndTurnState(endState);
      }

      _battle.isPlayerTurn = true;
      _battle.turnNumber++;

      // BUG-04: 自分のターン開始時の状態異常処理
      _processTurnStartEffects(_battle.player);

      // BUG-09: skipNextDraw チェック
      if (_battle.player.skipNextDraw) {
        _battle.player.skipNextDraw = false;
        _battle.addLog('⚠️ ${_battle.player.name}はドローをスキップ！', isPlayer: true);
      } else {
        if (_battle.player.deck.isNotEmpty) {
          final drawn = _battle.player.deck.removeAt(0);
          _battle.player.hand.add(drawn);
        } else if (_battle.player.graveyard.isNotEmpty) {
          _battle.player.deck = List.from(_battle.player.graveyard)..shuffle();
          _battle.player.graveyard.clear();
          if (_battle.player.deck.isNotEmpty) {
            _battle.player.hand.add(_battle.player.deck.removeAt(0));
          }
        }
      }

      // BUG-08: manaBoostNext はスナップショットから既に適用済みだが、
      // フォールバックとしてローカル値も使う
      _battle.player.mana = _battle.currentMaxMana + _battle.player.manaBoostNext;
      _battle.player.manaBoostNext = 0;
      _battle.addLog('--- ターン${_battle.turnNumber} あなたのターン ---', isPlayer: true);
    });
    _checkBattleEnd();
  }

  /// END_TURN スナップショットから相手・自分の状態を同期する
  void _applyEndTurnState(Map<String, dynamic> endState) {
    final playerData = endState['player'] as Map<String, dynamic>?;
    final enemyData  = endState['enemy']  as Map<String, dynamic>?;

    // 送信者 = 相手(enemy)、受信者 = 自分(player) という対応で適用
    if (!widget.isHost) {
      // ゲスト受信: state.player=ホスト(=enemy), state.enemy=ゲスト(=player)
      if (playerData != null) {
        _battle.enemy.hp              = playerData['hp']              as int? ?? _battle.enemy.hp;
        _battle.enemy.shield          = playerData['shield']          as int? ?? _battle.enemy.shield;
        _battle.enemy.mana            = playerData['mana']            as int? ?? _battle.enemy.mana;
        _battle.enemy.poisonTurns     = playerData['poisonTurns']     as int? ?? _battle.enemy.poisonTurns;
        _battle.enemy.trojanTurns     = playerData['trojanTurns']     as int? ?? _battle.enemy.trojanTurns;
        _battle.enemy.airgapTurns     = playerData['airgapTurns']     as int? ?? _battle.enemy.airgapTurns;
        _battle.enemy.regenShieldTurns= playerData['regenShieldTurns']as int? ?? _battle.enemy.regenShieldTurns;
        _battle.enemy.manaBoostNext   = playerData['manaBoostNext']   as int? ?? _battle.enemy.manaBoostNext;
        _battle.enemy.skipNextDraw    = playerData['skipNextDraw']    as bool? ?? _battle.enemy.skipNextDraw;
      }
      if (enemyData != null) {
        _battle.player.manaBoostNext  = enemyData['manaBoostNext']    as int? ?? _battle.player.manaBoostNext;
        _battle.player.skipNextDraw   = enemyData['skipNextDraw']     as bool? ?? _battle.player.skipNextDraw;
      }
    } else {
      // ホスト受信: state.player=ゲスト(=enemy), state.enemy=ホスト(=player)
      if (playerData != null) {
        _battle.enemy.hp              = playerData['hp']              as int? ?? _battle.enemy.hp;
        _battle.enemy.shield          = playerData['shield']          as int? ?? _battle.enemy.shield;
        _battle.enemy.mana            = playerData['mana']            as int? ?? _battle.enemy.mana;
        _battle.enemy.poisonTurns     = playerData['poisonTurns']     as int? ?? _battle.enemy.poisonTurns;
        _battle.enemy.trojanTurns     = playerData['trojanTurns']     as int? ?? _battle.enemy.trojanTurns;
        _battle.enemy.airgapTurns     = playerData['airgapTurns']     as int? ?? _battle.enemy.airgapTurns;
        _battle.enemy.regenShieldTurns= playerData['regenShieldTurns']as int? ?? _battle.enemy.regenShieldTurns;
        _battle.enemy.manaBoostNext   = playerData['manaBoostNext']   as int? ?? _battle.enemy.manaBoostNext;
        _battle.enemy.skipNextDraw    = playerData['skipNextDraw']    as bool? ?? _battle.enemy.skipNextDraw;
      }
      if (enemyData != null) {
        _battle.player.manaBoostNext  = enemyData['manaBoostNext']    as int? ?? _battle.player.manaBoostNext;
        _battle.player.skipNextDraw   = enemyData['skipNextDraw']     as bool? ?? _battle.player.skipNextDraw;
      }
    }
  }

  /// BUG-04修正: ターン開始時の状態異常カウントダウン＆ダメージ処理
  void _processTurnStartEffects(PlayerState active) {
    // エアギャップ
    if (active.airgapTurns > 0) {
      active.airgapTurns--;
      if (active.airgapTurns <= 0) active.airgapActive = false;
    }
    // トロイの木馬
    if (active.trojanTurns > 0) {
      active.trojanTurns--;
      final dmg = 2;
      final actualDmg = (active.shield >= dmg) ? 0 : dmg - active.shield;
      if (active.shield > 0) active.shield = (active.shield - dmg).clamp(0, 999);
      active.hp -= actualDmg;
      _battle.addLog('🦠 ${active.name}はトロイの木馬で${dmg}ダメージ！', isPlayer: active == _battle.player);
    }
    // 毒
    if (active.poisonTurns > 0) {
      active.poisonTurns--;
      final dmg = 3;
      final actualDmg = (active.shield >= dmg) ? 0 : dmg - active.shield;
      if (active.shield > 0) active.shield = (active.shield - dmg).clamp(0, 999);
      active.hp -= actualDmg;
      _battle.addLog('☠️ ${active.name}は毒で${dmg}ダメージ！', isPlayer: active == _battle.player);
    }
    // シールド再生
    if (active.regenShieldTurns > 0) {
      active.regenShieldTurns--;
      active.shield += 3;
      _battle.addLog('🛡️ ${active.name}のシールドが3回復！', isPlayer: active == _battle.player);
    }
  }

  void _handleDisconnect() {
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF0F1A2E),
        title: const Text('接続切断', style: TextStyle(color: Color(0xFFFF4444))),
        content: const Text(
          '相手との接続が切断されました。\nバトルは中断されます。',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF00FF88), foregroundColor: Colors.black),
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('メニューへ'),
          ),
        ],
      ),
    );
  }

  void _sendMessage(String type, Map<String, dynamic> data) {
    final msg = WifiP2pMessage(type: type, data: data);
    widget.wifiService?.sendMessage(msg);
    widget.onlineService?.sendGameMessage({'type': type, 'data': data});
  }

  void _onBattleUpdate() {
    if (!mounted) return;
    setState(() {});
    if (_battle.result != BattleResult.ongoing) {
      Future.delayed(const Duration(milliseconds: 800), _navigateToResult);
    }
  }

  void _checkBattleEnd() {
    if (_battle.player.hp <= 0 && _battle.enemy.hp <= 0) {
      setState(() => _battle.result = BattleResult.draw);
      Future.delayed(const Duration(milliseconds: 800), _navigateToResult);
    } else if (_battle.enemy.hp <= 0) {
      setState(() => _battle.result = BattleResult.playerWin);
      Future.delayed(const Duration(milliseconds: 800), _navigateToResult);
    } else if (_battle.player.hp <= 0) {
      setState(() => _battle.result = BattleResult.playerLose);
      Future.delayed(const Duration(milliseconds: 800), _navigateToResult);
    }
  }

  // BUG-03修正: _resultNavigated フラグで二重呼び出しを防止
  void _navigateToResult() async {
    if (_resultNavigated || !mounted) return;
    _resultNavigated = true;

    final gp = context.read<GameProvider>();
    final won = _battle.result == BattleResult.playerWin;
    await gp.reportPvpResult(won: won, mode: widget.mode);

    if (mounted) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => BattleResultScreen(
            result: _battle.result,
            stage: null,
            difficulty: 1,
            noPlayerDamage: _battle.noPlayerDamageTaken,
            usedLegendary: _usedLegendary,
            playerHp: _battle.player.hp,
            enemyHp: _battle.enemy.hp,
            turnNumber: _battle.turnNumber,
            isPvp: true,
            pvpMode: widget.mode,
          ),
        ),
      );
    }
  }

  @override
  void dispose() {
    try { _battle.removeListener(_onBattleUpdate); } catch (_) {}
    // Bug1修正: ポート9876/9877を確実に解放。しないと2回目でバインド失敗する
    widget.wifiService?.disconnect();
    widget.onlineService?.disconnect();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_waitingForOpponent) {
      return Scaffold(
        backgroundColor: const Color(0xFF050510),
        body: SafeArea(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const CircularProgressIndicator(color: Color(0xFF00FF88)),
                const SizedBox(height: 24),
                Text(
                  widget.isHost ? '相手の接続を待っています...' : '接続中...',
                  style: const TextStyle(color: Color(0xFF00FF88), fontSize: 14),
                ),
                const SizedBox(height: 8),
                Text(
                  widget.mode == 'wifi' ? '📶 WiFiローカル' : '🌍 オンライン',
                  style: const TextStyle(color: Color(0xFF444466), fontSize: 12),
                ),
                const SizedBox(height: 32),
                if (widget.isHost)
                  Container(
                    padding: const EdgeInsets.all(12),
                    margin: const EdgeInsets.symmetric(horizontal: 32),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0F1A2E),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: const Color(0xFF1A3A5C)),
                    ),
                    child: Column(
                      children: [
                        const Text('📡 ホスト待機中', style: TextStyle(color: Color(0xFF00FF88), fontSize: 12)),
                        const SizedBox(height: 4),
                        const Text(
                          'あなたのIPアドレスを相手に伝えてください',
                          style: TextStyle(color: Color(0xFF666688), fontSize: 10),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                const SizedBox(height: 24),
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('キャンセル', style: TextStyle(color: Color(0xFF666666))),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFF050510),
      body: SafeArea(
        child: Column(
          children: [
            // 相手HUD
            HudWidget(
              name: _battle.enemy.name,
              hp: _battle.enemy.hp, maxHp: _battle.enemy.maxHp,
              shield: _battle.enemy.shield, mana: _battle.enemy.mana,
              maxMana: _battle.currentMaxMana, isEnemy: true,
              poisonTurns: _battle.enemy.poisonTurns,
            ),
            // バトルログ
            Expanded(flex: 3, child: _buildBattleLog()),
            // ターン情報
            _buildTurnInfo(),
            // 自分HUD
            HudWidget(
              name: _battle.player.name,
              hp: _battle.player.hp, maxHp: _battle.player.maxHp,
              shield: _battle.player.shield, mana: _battle.player.mana,
              maxMana: _battle.currentMaxMana, isEnemy: false,
              poisonTurns: _battle.player.poisonTurns,
            ),
            // 手札
            Expanded(flex: 4, child: _buildHandArea()),
            // アクションバー
            _buildActionBar(),
          ],
        ),
      ),
    );
  }

  Widget _buildBattleLog() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: const Color(0xFF080812),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFF1A1A3A)),
      ),
      child: ListView.builder(
        reverse: true,
        itemCount: _battle.logs.length,
        itemBuilder: (context, index) {
          final log = _battle.logs[_battle.logs.length - 1 - index];
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 1),
            child: Text(
              log.message,
              style: TextStyle(
                color: log.isPlayerAction ? const Color(0xFF88FFAA) : const Color(0xFFFF8888),
                fontSize: 11, fontFamily: 'monospace',
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildTurnInfo() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text('TURN ${_battle.turnNumber}',
              style: const TextStyle(color: Color(0xFF00AAFF), fontSize: 12, fontWeight: FontWeight.bold)),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: (_battle.isPlayerTurn ? const Color(0xFF00FF88) : const Color(0xFFFF4444))
                  .withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                  color: (_battle.isPlayerTurn ? const Color(0xFF00FF88) : const Color(0xFFFF4444))
                      .withValues(alpha: 0.5)),
            ),
            child: Text(
              _battle.isPlayerTurn ? '✅ あなたのターン' : '⏳ 相手のターン',
              style: TextStyle(
                color: _battle.isPlayerTurn ? const Color(0xFF00FF88) : const Color(0xFFFF4444),
                fontSize: 11, fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Text(widget.mode == 'wifi' ? '📶 WiFi' : '🌍 Online',
              style: const TextStyle(color: Color(0xFF444466), fontSize: 10)),
        ],
      ),
    );
  }

  Widget _buildHandArea() {
    final hand = _battle.player.hand;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: hand.isEmpty
          ? const Center(child: Text('手札なし', style: TextStyle(color: Color(0xFF444466))))
          : ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: hand.length,
              itemBuilder: (context, i) {
                final cardId = hand[i];
                final card = CardDatabase.getById(cardId);
                if (card == null) return const SizedBox.shrink();
                final canPlay = _battle.isPlayerTurn &&
                    card.cost <= _battle.player.mana &&
                    _battle.result == BattleResult.ongoing;
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: CardWidget(
                    card: card, canPlay: canPlay,
                    showDetailOnLongPress: false,
                    onTap: () {
                      showCardDetailWithAction(
                        context: context,
                        card: card,
                        canUse: canPlay,
                        onUse: () => _playCard(cardId),
                      );
                    },
                  ),
                );
              },
            ),
    );
  }

  void _playCard(String cardId) {
    final card = CardDatabase.getById(cardId);
    if (card == null) return;
    if (card.rarity == CardRarity.legendary) _usedLegendary = true;

    // Bug2修正: playCard前後のログ差分を取得して相手に送る
    final logsBefore = _battle.logs.length;
    _battle.playCard(cardId);
    // playCard後に追加されたログメッセージを収集（カード効果の詳細ログ）
    final newLogs = _battle.logs
        .skip(logsBefore)
        .map((l) => {'msg': l.message, 'isPlayer': l.isPlayerAction})
        .toList();

    _sendMessage('PLAY_CARD', {
      'cardId': cardId,
      'state': _buildStateSnapshot(),
      'hand': _battle.player.hand,
      'logs': newLogs, // 相手側でも同じログを表示するために送信
    });
    setState(() {});
    _checkBattleEnd();
  }

  Widget _buildActionBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
      child: Row(
        children: [
          OutlinedButton(
            onPressed: () {
              showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  backgroundColor: const Color(0xFF0F1A2E),
                  title: const Text('降参', style: TextStyle(color: Color(0xFFFF4444))),
                  content: const Text('降参しますか？', style: TextStyle(color: Colors.white70)),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context),
                        child: const Text('戻る', style: TextStyle(color: Color(0xFF666666)))),
                    TextButton(
                      onPressed: () {
                        _sendMessage('SURRENDER', {});
                        Navigator.pop(context);
                        setState(() => _battle.result = BattleResult.playerLose);
                        _navigateToResult();
                      },
                      child: const Text('降参', style: TextStyle(color: Color(0xFFFF4444))),
                    ),
                  ],
                ),
              );
            },
            style: OutlinedButton.styleFrom(
              foregroundColor: const Color(0xFFFF4444),
              side: const BorderSide(color: Color(0xFF441111)),
            ),
            child: const Text('降参', style: TextStyle(fontSize: 12)),
          ),
          const Spacer(),
          // マナクリスタル
          Flexible(
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: List.generate(_battle.currentMaxMana, (i) => Container(
                  width: 10, height: 10,
                  margin: const EdgeInsets.symmetric(horizontal: 1),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: i < _battle.player.mana
                        ? const Color(0xFF00AAFF)
                        : const Color(0xFF1A1A3A),
                  ),
                )),
              ),
            ),
          ),
          const Spacer(),
          ElevatedButton(
            onPressed: (_battle.isPlayerTurn && _battle.result == BattleResult.ongoing)
                ? () {
                    // BUG-06修正: END_TURNのstateを受信側が使えるよう正しく構造化して送信
                    _sendMessage('END_TURN', {'state': _buildStateSnapshot()});
                    setState(() {
                      _battle.isPlayerTurn = false;
                      _battle.addLog('--- 相手のターン ---', isPlayer: false);
                    });
                  }
                : null,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF00FF88),
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              disabledBackgroundColor: const Color(0xFF1A2A1A),
            ),
            child: const Text('ターン終了', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
          ),
        ],
      ),
    );
  }
}
