import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/card_model.dart';
import '../providers/game_provider.dart';
import '../widgets/card_widget.dart';
class DeckEditScreen extends StatefulWidget {
  const DeckEditScreen({super.key});

  @override
  State<DeckEditScreen> createState() => _DeckEditScreenState();
}

class _DeckEditScreenState extends State<DeckEditScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;
  List<String> _editingDeck = [];

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
    final gp = context.read<GameProvider>();
    _editingDeck = List.from(gp.deckCardIds);
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<GameProvider>(
      builder: (context, gp, _) {
        final unlocked = gp.unlockedCardIds.toSet().toList();

        return Scaffold(
          backgroundColor: const Color(0xFF0A0A1A),
          appBar: AppBar(
            backgroundColor: const Color(0xFF0F1A2E),
            title: const Text(
              'DECK EDITOR',
              style: TextStyle(
                color: Color(0xFFFFAA00),
                letterSpacing: 2,
                fontWeight: FontWeight.bold,
              ),
            ),
            leading: IconButton(
              icon: const Icon(Icons.arrow_back, color: Color(0xFFFFAA00)),
              onPressed: () => Navigator.pop(context),
            ),
            actions: [
              // 保存ボタン
              TextButton(
                onPressed: _editingDeck.length == 20
                    ? () async {
                        await gp.updateDeck(_editingDeck);
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('✅ デッキを保存しました！'),
                              backgroundColor: Color(0xFF00FF88),
                            ),
                          );
                          Navigator.pop(context);
                        }
                      }
                    : null,
                child: Text(
                  '保存 (${_editingDeck.length}/20)',
                  style: TextStyle(
                    color: _editingDeck.length == 20
                        ? const Color(0xFF00FF88)
                        : const Color(0xFF666666),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
            bottom: TabBar(
              controller: _tabCtrl,
              indicatorColor: const Color(0xFFFFAA00),
              labelColor: const Color(0xFFFFAA00),
              unselectedLabelColor: const Color(0xFF666666),
              tabs: const [
                Tab(text: 'マイデッキ'),
                Tab(text: 'カード一覧'),
              ],
            ),
          ),
          body: TabBarView(
            controller: _tabCtrl,
            children: [
              _buildMyDeck(unlocked),
              _buildCardList(unlocked),
            ],
          ),
        );
      },
    );
  }

  Widget _buildMyDeck(List<String> unlocked) {
    return Column(
      children: [
        // デッキ状態バー
        Container(
          padding: const EdgeInsets.all(12),
          color: const Color(0xFF0F1A2E),
          child: Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'デッキ: ${_editingDeck.length}/20',
                    style: TextStyle(
                      color: _editingDeck.length == 20
                          ? const Color(0xFF00FF88)
                          : const Color(0xFFFFAA00),
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                  if (_editingDeck.length < 20)
                    Text(
                      'あと${20 - _editingDeck.length}枚追加してください',
                      style: const TextStyle(color: Color(0xFF666688), fontSize: 10),
                    ),
                ],
              ),
              const Spacer(),
              TextButton(
                onPressed: () => setState(() => _editingDeck.clear()),
                child: const Text(
                  'クリア',
                  style: TextStyle(color: Color(0xFFFF4444), fontSize: 12),
                ),
              ),
            ],
          ),
        ),
        // デッキカード一覧
        Expanded(
          child: _editingDeck.isEmpty
              ? const Center(
                  child: Text(
                    'カードを追加してください\n(合計20枚必要)',
                    style: TextStyle(color: Color(0xFF444466), fontSize: 13),
                    textAlign: TextAlign.center,
                  ),
                )
              : GridView.builder(
                  padding: const EdgeInsets.all(8),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 0.75,
                    crossAxisSpacing: 8,
                    mainAxisSpacing: 8,
                  ),
                  itemCount: _editingDeck.length,
                  itemBuilder: (context, index) {
                    final cardId = _editingDeck[index];
                    final card = CardDatabase.getById(cardId);
                    if (card == null) return const SizedBox.shrink();
                    return Stack(
                      children: [
                        CardWidget(card: card, canPlay: false, compact: true),
                        Positioned(
                          top: 4,
                          right: 4,
                          child: GestureDetector(
                            onTap: () => setState(() => _editingDeck.removeAt(index)),
                            child: Container(
                              width: 22,
                              height: 22,
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: Color(0xFFFF4444),
                              ),
                              child: const Icon(Icons.remove, size: 14, color: Colors.white),
                            ),
                          ),
                        ),
                      ],
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildCardList(List<String> unlocked) {
    final available = CardDatabase.allCards;
    final types = ['全て', 'attack', 'defense', 'special', 'exploit'];
    return StatefulBuilder(
      builder: (context, setFilterState) {
        int filterIdx = 0;
        return Column(
          children: [
            // フィルタバー
            SizedBox(
              height: 40,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 8),
                itemCount: types.length,
                itemBuilder: (context, i) {
                  return GestureDetector(
                    onTap: () => setFilterState(() => filterIdx = i),
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      decoration: BoxDecoration(
                        color: filterIdx == i
                            ? const Color(0xFFFFAA00)
                            : const Color(0xFF0F1A2E),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: filterIdx == i
                              ? const Color(0xFFFFAA00)
                              : const Color(0xFF1A3A5C),
                        ),
                      ),
                      child: Text(
                        types[i],
                        style: TextStyle(
                          color: filterIdx == i ? Colors.black : const Color(0xFF666688),
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.all(8),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 0.75,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                ),
                itemCount: available.length,
                itemBuilder: (context, index) {
                  final card = available[index];
                  final isUnlocked = unlocked.contains(card.id);
                  final deckCount = _editingDeck.where((id) => id == card.id).length;
                  final canAdd = isUnlocked && _editingDeck.length < 20 && deckCount < 2;

                  return GestureDetector(
                    // タップ → 詳細ダイアログ
                    onTap: () => showCardDetail(context, card),
                    // 長押し → デッキに追加（アンロック済みのみ）
                    onLongPress: canAdd
                        ? () {
                            setState(() => _editingDeck.add(card.id));
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text('「${card.name}」をデッキに追加'),
                                duration: const Duration(seconds: 1),
                                backgroundColor: const Color(0xFF00FF88),
                              ),
                            );
                          }
                        : null,
                    child: Stack(
                    children: [
                      Opacity(
                        opacity: isUnlocked ? 1.0 : 0.35,
                        child: CardWidget(
                          card: card,
                          canPlay: canAdd,
                          compact: true,
                          showDetailOnLongPress: false, // GestureDetectorで管理
                        ),
                      ),
                      if (!isUnlocked)
                        const Positioned.fill(
                          child: Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.lock, color: Color(0xFF666688), size: 28),
                                Text(
                                  'LOCKED',
                                  style: TextStyle(
                                    color: Color(0xFF666688),
                                    fontSize: 10,
                                    letterSpacing: 1,
                                  ),
                                ),
                                Text(
                                  'タップで確認',
                                  style: TextStyle(
                                    color: Color(0xFF444466),
                                    fontSize: 8,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      if (isUnlocked && deckCount > 0)
                        Positioned(
                          top: 4,
                          left: 4,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: const Color(0xFF00FF88),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              '×$deckCount',
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      // 長押しで追加ヒント
                      if (canAdd)
                        const Positioned(
                          bottom: 6,
                          right: 4,
                          child: Text(
                            '長押し追加',
                            style: TextStyle(color: Color(0xFF444466), fontSize: 7),
                          ),
                        ),
                    ],
                  ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }
}
