import 'package:flutter/foundation.dart';
import '../models/card_model.dart';
import '../models/game_models.dart';
import '../services/save_service.dart';

class GameProvider extends ChangeNotifier {
  SaveData _saveData = SaveData();
  bool _isLoaded = false;

  SaveData get saveData => _saveData;
  bool get isLoaded => _isLoaded;

  int get level => _saveData.level;
  int get totalXp => _saveData.totalXp;
  int get totalWins => _saveData.totalWins;
  int get totalLosses => _saveData.totalLosses;
  List<String> get deckCardIds => _saveData.deckCardIds;
  List<String> get unlockedCardIds => _saveData.unlockedCardIds;
  List<int> get clearedStages => _saveData.clearedStages;
  List<String> get earnedAchievementIds => _saveData.earnedAchievementIds;
  bool get ngPlusUnlocked => _saveData.ngPlusUnlocked;
  String get playerName => _saveData.playerName;
  PlayerRole get playerRole => _saveData.playerRole;

  int get xpInLevel => SaveService.xpInCurrentLevel(_saveData.totalXp, _saveData.level);
  int get xpForNextLevel => SaveService.xpForLevel(_saveData.level);

  Future<void> loadSave() async {
    _saveData = await SaveService.load();
    _isLoaded = true;
    notifyListeners();
  }

  Future<void> _save() async => await SaveService.save(_saveData);

  // ステージクリア報告
  Future<List<String>> reportStageCleared({
    required int stageId,
    required bool won,
    required bool noPlayerDamage,
    required bool usedLegendary,
    required int difficulty,
  }) async {
    List<String> newAchievements = [];

    if (won) {
      _saveData.totalWins++;
      if (!_saveData.clearedStages.contains(stageId)) {
        _saveData.clearedStages.add(stageId);
      }

      final stage = StageDatabase.getById(stageId);
      if (stage != null) {
        int xpGain = stage.rewardXp;
        if (difficulty == 2) xpGain = (xpGain * 1.5).round();
        _saveData.totalXp += xpGain;
        _saveData.level = SaveService.calcLevel(_saveData.totalXp);

        if (stage.unlockCardId != null &&
            !_saveData.unlockedCardIds.contains(stage.unlockCardId)) {
          _saveData.unlockedCardIds.add(stage.unlockCardId!);
        }
      }

      // NG+解放（ステージ8クリアで全カードアンロック）
      if (stageId == 8 && !_saveData.ngPlusUnlocked) {
        _saveData.ngPlusUnlocked = true;
        for (final id in CardDatabase.unlockOrder) {
          if (!_saveData.unlockedCardIds.contains(id)) {
            _saveData.unlockedCardIds.add(id);
          }
        }
      }

      newAchievements.addAll(_checkAchievements(
        stageId: stageId,
        noPlayerDamage: noPlayerDamage,
        usedLegendary: usedLegendary,
        difficulty: difficulty,
      ));
    } else {
      _saveData.totalLosses++;
    }

    await _save();
    notifyListeners();
    return newAchievements;
  }

  Future<List<String>> reportPvpResult({
    required bool won,
    required String mode, // 'online' or 'wifi'
  }) async {
    List<String> newAchievements = [];
    if (won) {
      _saveData.totalWins++;
      _saveData.totalXp += 300;
      _saveData.level = SaveService.calcLevel(_saveData.totalXp);
      final achId = mode == 'wifi' ? 'wifi_win' : 'online_win';
      if (!_saveData.earnedAchievementIds.contains(achId)) {
        _saveData.earnedAchievementIds.add(achId);
        newAchievements.add(achId);
      }
    } else {
      _saveData.totalLosses++;
    }
    await _save();
    notifyListeners();
    return newAchievements;
  }

  List<String> _checkAchievements({
    required int stageId,
    required bool noPlayerDamage,
    required bool usedLegendary,
    required int difficulty,
  }) {
    List<String> newOnes = [];
    void tryUnlock(String id) {
      if (!_saveData.earnedAchievementIds.contains(id)) {
        _saveData.earnedAchievementIds.add(id);
        newOnes.add(id);
      }
    }

    if (_saveData.totalWins == 1) tryUnlock('first_win');
    if (_saveData.clearedStages.contains(3)) tryUnlock('stage_3');
    if (_saveData.clearedStages.contains(5)) tryUnlock('stage_5');
    if (_saveData.clearedStages.contains(8)) tryUnlock('stage_8');
    if (_saveData.clearedStages.contains(9)) tryUnlock('stage_9');
    if (_saveData.totalWins >= 10) tryUnlock('win_10');
    if (noPlayerDamage) tryUnlock('no_damage');
    if (difficulty == 2) tryUnlock('hard_win');
    if (usedLegendary) tryUnlock('legendary_play');
    if (_saveData.playerRole == PlayerRole.black) tryUnlock('black_role');
    if (_saveData.unlockedCardIds.length >= CardDatabase.allCards.length) tryUnlock('all_cards');

    // フルデッキ実績（20枚全て異なるカード）
    if (_saveData.deckCardIds.toSet().length >= 20) tryUnlock('full_deck');

    return newOnes;
  }

  Future<void> unlockAchievement(String id) async {
    if (!_saveData.earnedAchievementIds.contains(id)) {
      _saveData.earnedAchievementIds.add(id);
      await _save();
      notifyListeners();
    }
  }

  // デッキ更新（20枚）
  Future<void> updateDeck(List<String> newDeck) async {
    _saveData.deckCardIds = List.from(newDeck);
    await _save();
    notifyListeners();
  }

  // 名前更新
  Future<void> updateName(String name) async {
    _saveData.playerName = name;
    await _save();
    notifyListeners();
  }

  // ロール切替（ホワイト / ブラック）
  Future<void> toggleRole() async {
    _saveData.playerRole = _saveData.playerRole == PlayerRole.white
        ? PlayerRole.black
        : PlayerRole.white;
    await _save();
    notifyListeners();
  }

  Future<void> setRole(PlayerRole role) async {
    _saveData.playerRole = role;
    await _save();
    notifyListeners();
  }

  Future<void> resetSave() async {
    await SaveService.reset();
    _saveData = SaveData();
    await _save();
    notifyListeners();
  }
}
