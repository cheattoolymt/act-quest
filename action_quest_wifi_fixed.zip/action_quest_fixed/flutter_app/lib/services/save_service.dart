import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/card_model.dart';
import '../models/game_models.dart';

class SaveData {
  int totalXp;
  int level;
  List<String> unlockedCardIds;
  List<String> deckCardIds;
  List<int> clearedStages;
  List<String> earnedAchievementIds;
  Map<String, int> stageHighScores;
  int totalWins;
  int totalLosses;
  bool ngPlusUnlocked;
  String playerName;
  PlayerRole playerRole;

  SaveData({
    this.totalXp = 0,
    this.level = 1,
    List<String>? unlockedCardIds,
    List<String>? deckCardIds,
    List<int>? clearedStages,
    List<String>? earnedAchievementIds,
    Map<String, int>? stageHighScores,
    this.totalWins = 0,
    this.totalLosses = 0,
    this.ngPlusUnlocked = false,
    this.playerName = 'WHITE HACKER',
    this.playerRole = PlayerRole.white,
  })  : unlockedCardIds = unlockedCardIds ?? _defaultUnlocked(),
        deckCardIds = deckCardIds ?? List.from(CardDatabase.starterDeckIds),
        clearedStages = clearedStages ?? [],
        earnedAchievementIds = earnedAchievementIds ?? [],
        stageHighScores = stageHighScores ?? {};

  static List<String> _defaultUnlocked() {
    // 最初からアンロックされているカード
    return [
      'atk_001', 'atk_002', 'atk_006', 'atk_013',
      'def_001', 'def_002', 'def_009', 'def_010',
      'spc_002', 'spc_003', 'spc_004', 'spc_007',
      'exp_002', 'atk_003', 'def_003',
    ];
  }

  Map<String, dynamic> toJson() => {
    'totalXp': totalXp,
    'level': level,
    'unlockedCardIds': unlockedCardIds,
    'deckCardIds': deckCardIds,
    'clearedStages': clearedStages,
    'earnedAchievementIds': earnedAchievementIds,
    'stageHighScores': stageHighScores,
    'totalWins': totalWins,
    'totalLosses': totalLosses,
    'ngPlusUnlocked': ngPlusUnlocked,
    'playerName': playerName,
    'playerRole': playerRole.index,
  };

  factory SaveData.fromJson(Map<String, dynamic> json) => SaveData(
    totalXp: json['totalXp'] ?? 0,
    level: json['level'] ?? 1,
    unlockedCardIds: List<String>.from(json['unlockedCardIds'] ?? _defaultUnlocked()),
    deckCardIds: List<String>.from(json['deckCardIds'] ?? CardDatabase.starterDeckIds),
    clearedStages: List<int>.from(json['clearedStages'] ?? []),
    earnedAchievementIds: List<String>.from(json['earnedAchievementIds'] ?? []),
    stageHighScores: Map<String, int>.from(json['stageHighScores'] ?? {}),
    totalWins: json['totalWins'] ?? 0,
    totalLosses: json['totalLosses'] ?? 0,
    ngPlusUnlocked: json['ngPlusUnlocked'] ?? false,
    playerName: json['playerName'] ?? 'WHITE HACKER',
    playerRole: PlayerRole.values[json['playerRole'] ?? 0],
  );
}

class SaveService {
  static const String _key = 'action_quest_save_v2';

  static Future<SaveData> load() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonStr = prefs.getString(_key);
    if (jsonStr == null) return SaveData();
    try {
      return SaveData.fromJson(jsonDecode(jsonStr));
    } catch (_) {
      return SaveData();
    }
  }

  static Future<void> save(SaveData data) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(data.toJson()));
  }

  static Future<void> reset() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }

  static int xpForLevel(int level) => level * 200 + (level - 1) * 50;

  static int calcLevel(int totalXp) {
    int lv = 1;
    int xp = totalXp;
    while (xp >= xpForLevel(lv) && lv < 100) {
      xp -= xpForLevel(lv);
      lv++;
    }
    return lv;
  }

  static int xpInCurrentLevel(int totalXp, int level) {
    int xp = totalXp;
    for (int lv = 1; lv < level; lv++) {
      xp -= xpForLevel(lv);
    }
    return xp < 0 ? 0 : xp;
  }
}
