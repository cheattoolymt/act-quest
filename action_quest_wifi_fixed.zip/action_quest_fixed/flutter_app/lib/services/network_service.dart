import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:network_info_plus/network_info_plus.dart';

// ===== 共通メッセージ型 =====
class WifiP2pMessage {
  final String type;
  final Map<String, dynamic> data;
  WifiP2pMessage({required this.type, required this.data});

  String toJson() => jsonEncode({'type': type, 'data': data});

  factory WifiP2pMessage.fromJson(String s) {
    final m = jsonDecode(s) as Map<String, dynamic>;
    return WifiP2pMessage(
      type: m['type'] as String? ?? '',
      data: Map<String, dynamic>.from(m['data'] as Map? ?? {}),
    );
  }
}

// ===== TCP P2P 共通ベース =====
abstract class _TcpP2pBase extends ChangeNotifier {
  bool _disposed = false;
  String _statusMessage = 'オフライン';
  bool _connected = false;
  String _localIp = '';
  String _remoteIp = '';
  bool _isHost = false;

  ServerSocket? _server;
  Socket? _socket;
  Timer? _heartbeat;
  String _recvBuf = '';

  String get statusMessage => _statusMessage;
  String get localIp => _localIp;
  bool get isConnected => _connected;
  bool get isHost => _isHost;

  Function(WifiP2pMessage)? onMessage;
  Function()? onConnected;
  Function()? onDisconnected;
  Function(WifiP2pMessage)? get onWifiMessage => onMessage;
  Function()? onOpponentConnected;
  Function()? onOpponentDisconnected;

  void _setState(String msg, {bool connected = false}) {
    _statusMessage = msg;
    _connected = connected;
    if (!_disposed) notifyListeners();
  }

  /// Android 8〜16対応: 複数の方法でローカルIPを取得
  Future<String> _getLocalIp() async {
    final candidates = <String>[];

    // 方法1: network_info_plus (WiFi専用、権限が付与されている場合のみ有効)
    try {
      final info = NetworkInfo();
      final ip = await info.getWifiIP().timeout(const Duration(seconds: 3));
      if (ip != null && ip != '0.0.0.0' && ip.isNotEmpty && ip != 'null') {
        candidates.add(ip);
        if (kDebugMode) debugPrint('[P2P] NetworkInfo IP: $ip');
      }
    } catch (e) {
      if (kDebugMode) debugPrint('[P2P] NetworkInfo failed: $e');
    }

    // 方法2: NetworkInterface一覧から全アドレスを収集（権限不要、最も安定）
    try {
      final interfaces = await NetworkInterface.list(
        type: InternetAddressType.IPv4,
        includeLinkLocal: false,
      );
      for (final iface in interfaces) {
        for (final addr in iface.addresses) {
          if (!addr.isLoopback && addr.address != '0.0.0.0') {
            candidates.add(addr.address);
            if (kDebugMode) debugPrint('[P2P] Interface ${iface.name}: ${addr.address}');
          }
        }
      }
    } catch (e) {
      if (kDebugMode) debugPrint('[P2P] NetworkInterface.list failed: $e');
    }

    // 優先順位: 192.168.x.x > 10.x.x.x > 172.16-31.x.x > その他
    for (final ip in candidates) {
      if (ip.startsWith('192.168.')) return ip;
    }
    for (final ip in candidates) {
      if (ip.startsWith('10.')) return ip;
    }
    for (final ip in candidates) {
      final parts = ip.split('.');
      if (parts.length == 4) {
        final second = int.tryParse(parts[1]) ?? 0;
        if (ip.startsWith('172.') && second >= 16 && second <= 31) return ip;
      }
    }
    if (candidates.isNotEmpty) return candidates.first;

    // 方法3: TCP connect trick（ルーターへ接続して送信元IPを特定）
    // candidates が空のとき（Android 8でNetworkInterface.listが失敗した場合）に使用
    try {
      final socket = await Socket.connect(
        '8.8.8.8', 80,
        timeout: const Duration(seconds: 3),
      );
      final localIp = socket.address.address;
      await socket.close();
      if (localIp != '0.0.0.0' && localIp != '127.0.0.1') {
        if (kDebugMode) debugPrint('[P2P] connect trick IP: $localIp');
        return localIp;
      }
    } catch (e) {
      if (kDebugMode) debugPrint('[P2P] connect trick failed: $e');
    }

    if (kDebugMode) debugPrint('[P2P] Could not get local IP, returning 0.0.0.0');
    return '0.0.0.0';
  }

  // ホスト起動（TCPサーバー）- shared: false でAndroid 8対応
  Future<void> _startServer(int port) async {
    _localIp = await _getLocalIp();
    _isHost = true;

    if (_localIp == '0.0.0.0') {
      _setState('❌ WiFi IPアドレスが取得できません\n'
          'WiFiに接続されていることを確認してください\n'
          '（モバイルデータではなくWiFiを使用）');
      return;
    }

    // 既存サーバーを閉じる
    try { await _server?.close(); } catch (_) {}
    _server = null;

    try {
      // shared: false でバインド (Android 8との互換性)
      _server = await ServerSocket.bind(
        InternetAddress.anyIPv4,
        port,
        shared: false,
      );
      if (kDebugMode) debugPrint('[P2P] Server bound on port $port, localIp=$_localIp');
      _setState('📡 ホスト待機中\n'
          'あなたのIP: $_localIp\n'
          'ポート: $port\n'
          '相手にこのIPを伝えてください');
      _server!.listen(
        (socket) {
          if (_socket != null) {
            socket.destroy();
            return;
          }
          _remoteIp = socket.remoteAddress.address;
          _socket = socket;
          _setupSocket(socket);
          _setState('✅ 接続成功！ゲーム開始準備中...', connected: true);
          onConnected?.call();
          onOpponentConnected?.call();
        },
        onError: (e) {
          if (kDebugMode) debugPrint('[P2P] Server error: $e');
          _setState('❌ サーバーエラー: $e');
        },
      );
    } on SocketException catch (e) {
      if (kDebugMode) debugPrint('[P2P] Bind failed: $e');
      // ポートが使用中の場合、別ポートを試す
      final altPort = port + 1;
      try {
        _server = await ServerSocket.bind(
          InternetAddress.anyIPv4,
          altPort,
          shared: false,
        );
        if (kDebugMode) debugPrint('[P2P] Server bound on alt port $altPort');
        _setState('📡 ホスト待機中\n'
            'あなたのIP: $_localIp\n'
            'ポート: $altPort (代替)\n'
            '相手にこのIPを伝えてください');
        _server!.listen(
          (socket) {
            if (_socket != null) { socket.destroy(); return; }
            _remoteIp = socket.remoteAddress.address;
            _socket = socket;
            _setupSocket(socket);
            _setState('✅ 接続成功！', connected: true);
            onConnected?.call();
            onOpponentConnected?.call();
          },
          onError: (e) => _setState('❌ サーバーエラー: $e'),
        );
      } catch (e2) {
        _setState('❌ ポートバインド失敗\n'
            'port $port と $altPort 両方が使用中です\n'
            'アプリを再起動してください\n'
            'エラー: ${e.message}');
      }
    }
  }

  // ゲスト接続（TCPクライアント）- Android 8対応強化版
  Future<bool> _connectTo(String hostIp, int port, {int timeoutSec = 10}) async {
    _localIp = await _getLocalIp();
    _isHost = false;
    _remoteIp = hostIp.trim();

    // IPアドレスバリデーション
    final ipRegex = RegExp(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$');
    if (!ipRegex.hasMatch(_remoteIp)) {
      _setState('❌ IPアドレスの形式が正しくありません\n'
          '例: 192.168.1.100\n'
          '入力値: $_remoteIp');
      return false;
    }

    _setState('🔄 接続中: $_remoteIp:$port ...');

    // 5回リトライ、各10秒タイムアウト
    for (int attempt = 1; attempt <= 5; attempt++) {
      try {
        _setState('🔄 接続試行 $attempt/5 → $_remoteIp:$port');
        if (kDebugMode) debugPrint('[P2P] Connecting to $_remoteIp:$port (attempt $attempt)');

        final socket = await Socket.connect(
          _remoteIp,
          port,
          timeout: Duration(seconds: timeoutSec),
        );
        _socket = socket;
        _setupSocket(socket);
        if (kDebugMode) debugPrint('[P2P] Connected successfully!');
        _setState('✅ 接続成功！ゲーム開始準備中...', connected: true);
        onConnected?.call();
        onOpponentConnected?.call();
        return true;
      } on SocketException catch (e) {
        if (kDebugMode) debugPrint('[P2P] SocketException (attempt $attempt): ${e.message}, osError=${e.osError}');
        final errMsg = e.osError?.message ?? e.message;
        if (attempt < 5) {
          _setState('⏳ 再試行中... ($attempt/5)\n'
              'エラー: $errMsg\n'
              '→ $_remoteIp:$port');
          await Future.delayed(const Duration(seconds: 3));
        } else {
          _setState('❌ 接続失敗 (5回試行)\n'
              'ホストIP: $_remoteIp\n'
              'ポート: $port\n'
              '確認事項:\n'
              '① 同じWiFiに繋がっているか？\n'
              '② ホストが「ホスト」を押しているか？\n'
              '③ IPアドレスは正しいか？\n'
              'エラー: $errMsg');
        }
      } on TimeoutException {
        if (kDebugMode) debugPrint('[P2P] Timeout (attempt $attempt)');
        if (attempt < 5) {
          _setState('⏳ タイムアウト ($attempt/5) → 再試行中...\n'
              '→ $_remoteIp:$port');
          await Future.delayed(const Duration(seconds: 2));
        } else {
          _setState('❌ 接続タイムアウト (5回)\n'
              'ホストIP: $_remoteIp\n'
              'ポート: $port が応答しません\n'
              '① ホストが「ホスト」ボタンを押しているか？\n'
              '② 同じWiFiに接続しているか？');
        }
      } catch (e) {
        if (kDebugMode) debugPrint('[P2P] Unexpected error (attempt $attempt): $e');
        _setState('❌ 予期しないエラー: $e');
        break;
      }
    }
    return false;
  }

  void _setupSocket(Socket socket) {
    try {
      socket.setOption(SocketOption.tcpNoDelay, true);
    } catch (e) {
      if (kDebugMode) debugPrint('[P2P] setOption failed (ignored): $e');
    }
    socket.listen(
      (data) {
        _recvBuf += utf8.decode(data, allowMalformed: true);
        _processBuffer();
      },
      onDone: () {
        if (!_disposed) {
          _setState('⚠️ 接続が切断されました');
          _connected = false;
          onDisconnected?.call();
          onOpponentDisconnected?.call();
        }
      },
      onError: (e) {
        if (!_disposed) {
          if (kDebugMode) debugPrint('[P2P] Socket error: $e');
          _setState('❌ 通信エラー: $e');
          _connected = false;
          onDisconnected?.call();
          onOpponentDisconnected?.call();
        }
      },
      cancelOnError: false,
    );

    // ハートビート（30秒ごと）
    _heartbeat?.cancel();
    _heartbeat = Timer.periodic(const Duration(seconds: 30), (_) {
      _rawSend({'type': 'HB', 'data': {}});
    });
  }

  void _processBuffer() {
    while (_recvBuf.contains('\n')) {
      final idx = _recvBuf.indexOf('\n');
      final line = _recvBuf.substring(0, idx).trim();
      _recvBuf = _recvBuf.substring(idx + 1);
      if (line.isEmpty) continue;
      try {
        final raw = jsonDecode(line) as Map<String, dynamic>;
        if (raw['type'] == 'HB') continue;
        final msg = WifiP2pMessage(
          type: raw['type'] as String? ?? '',
          data: Map<String, dynamic>.from(raw['data'] as Map? ?? {}),
        );
        onMessage?.call(msg);
      } catch (e) {
        if (kDebugMode) debugPrint('[P2P] Parse error: $e | line: $line');
      }
    }
  }

  void _rawSend(Map<String, dynamic> data) {
    try {
      _socket?.write('${jsonEncode(data)}\n');
    } catch (e) {
      if (kDebugMode) debugPrint('[P2P] Send error: $e');
    }
  }

  Future<void> sendMessage(WifiP2pMessage msg) async {
    if (!_connected) return;
    _rawSend({'type': msg.type, 'data': msg.data});
  }

  void sendGameMessage(Map<String, dynamic> data) {
    if (!_connected) return;
    _rawSend(data);
  }

  Future<void> disconnect() async {
    _connected = false;
    _heartbeat?.cancel();
    _heartbeat = null;
    try { await _socket?.close(); } catch (_) {}
    try { await _server?.close(); } catch (_) {}
    _socket = null;
    _server = null;
    _recvBuf = '';
    if (!_disposed) _setState('オフライン');
  }

  @override
  void dispose() {
    _disposed = true;
    disconnect();
    super.dispose();
  }
}

// ===== WiFi ローカル P2P (TCP, port 9876) =====
enum WifiP2pState { idle, hosting, connecting, connected, error }

class WifiP2pService extends _TcpP2pBase {
  static const int _port = 9876;

  WifiP2pState _wState = WifiP2pState.idle;
  WifiP2pState get state => _wState;

  @override
  void _setState(String msg, {bool connected = false}) {
    if (connected) {
      _wState = WifiP2pState.connected;
    } else if (msg.startsWith('❌')) {
      _wState = WifiP2pState.error;
    } else if (msg.contains('待機中')) {
      _wState = WifiP2pState.hosting;
    } else if (msg.contains('接続中') || msg.contains('再試行') || msg.contains('タイムアウト')) {
      _wState = WifiP2pState.connecting;
    } else if (!connected) {
      _wState = WifiP2pState.idle;
    }
    super._setState(msg, connected: connected);
  }

  Future<void> startHost() => _startServer(_port);
  Future<bool> connectToHost(String hostIp) => _connectTo(hostIp, _port);
}

// ===== オンライン P2P (TCP, port 9877) =====
enum OnlineState { idle, hosting, joining, connected, error }

class OnlineP2pService extends _TcpP2pBase {
  static const int _port = 9877;

  OnlineState _oState = OnlineState.idle;
  String _roomCode = '';

  OnlineState get state => _oState;
  String get roomCode => _roomCode;

  @override
  void _setState(String msg, {bool connected = false}) {
    if (connected) {
      _oState = OnlineState.connected;
    } else if (msg.startsWith('❌')) {
      _oState = OnlineState.error;
    } else if (msg.contains('ホスト待機中')) {
      _oState = OnlineState.hosting;
    } else if (msg.contains('接続中') || msg.contains('再試行') || msg.contains('タイムアウト')) {
      _oState = OnlineState.joining;
    } else {
      _oState = OnlineState.idle;
    }
    super._setState(msg, connected: connected);
  }

  Future<String> createRoom() async {
    await _startServer(_port);
    await Future.delayed(const Duration(milliseconds: 300));
    final parts = _localIp.split('.');
    if (parts.length == 4) {
      final c = int.tryParse(parts[2]) ?? 0;
      final d = int.tryParse(parts[3]) ?? 0;
      _roomCode = '${c.toString().padLeft(3, '0')}${d.toString().padLeft(3, '0')}';
    } else {
      _roomCode = '------';
    }
    return _roomCode;
  }

  Future<bool> joinRoom(String hostIp) => _connectTo(hostIp, _port, timeoutSec: 10);
}
